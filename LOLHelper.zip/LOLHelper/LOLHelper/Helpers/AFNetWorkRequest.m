//
//  AFNetWorkRequest.m
//  UltronNews
//
//  Created by lanouhn on 15/6/10.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "AFNetWorkRequest.h"
#import "AFNetworking.h"


@implementation AFNetWorkRequest

+ (void)getDataWithUrlStr:(NSString *)urlStr result:(Result)result {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manager GET:urlStr parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {//responseObject 存放请求到的数据
        result(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error = %@", error);
    }];
}

//封装的AFNetworking用法
//- (void)getRollingCellDataWithAPI:(NSString *)api keyForDic:(NSString *)key {
//    [NetworkDeal getDataWithUrlStr:api result:^(NSData *data) {
//        NSArray *rollingArr = [data valueForKey:key];
//        [self.rollingDataSource removeAllObjects];
//        [self.rollingTitleArr removeAllObjects];
//        [self.rollingImageSrcArr removeAllObjects];
//        [self.rollingDataSource removeAllObjects];
//        for (NSDictionary *dic in rollingArr) {
//            [self.rollingTitleArr addObject:dic[@"title"]];
//            [self.rollingImageSrcArr addObject:dic[@"imgsrc"]];
//        }
//        //将遍历出来的数组封装入Model中
//        RollingModel *model = [RollingModel rollingModelWithTitleArr:self.rollingTitleArr imageArr:self.rollingImageSrcArr];
//        //将Model添加入数据源
//        [self.rollingDataSource addObject:model];
//        [self.subTableView reloadData];
//    }];
//}
@end
