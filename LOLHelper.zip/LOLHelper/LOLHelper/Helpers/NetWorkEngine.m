//
//  NetWorkEngine.m
//  FingertipNews
//
//  Created by lanouhn on 15/6/4.
//  Copyright (c) 2015年 Redboyer. All rights reserved.
//

#import "NetWorkEngine.h"

@interface NetWorkEngine () <NSURLConnectionDataDelegate>
@property (nonatomic, retain) NSURLConnection *connection;
@property (nonatomic, retain) NSMutableData *mData;
@end

@implementation NetWorkEngine
//请求数据 - GET异步请求
- (void)loadDataWithString:(NSString *)string {
    NSString *urlStr = [NSString stringWithFormat:@"%@", string];
    NSURL *url = [NSURL URLWithString:urlStr];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    self.connection = [NSURLConnection connectionWithRequest:request delegate:self];
}

#pragma mark - NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    self.mData = [NSMutableData dataWithCapacity:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.mData  appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    //当数据请求完毕时让代理响应方法
    if ([self.delegate respondsToSelector:@selector(parserDataWithData:)]) {
        [self.delegate parserDataWithData:self.mData];
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    if ([self.delegate respondsToSelector:@selector(failedLoadData)]) {
        [self.delegate failedLoadData];
    }
}


@end
