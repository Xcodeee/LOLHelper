//
//  AFNetWorkRequest.h
//  UltronNews
//
//  Created by lanouhn on 15/6/10.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <Foundation/Foundation.h>

//定义block传值
typedef void (^Result) (NSData *data);

@interface AFNetWorkRequest : NSObject

+ (void)getDataWithUrlStr:(NSString *)urlStr result:(Result)result;



@end
