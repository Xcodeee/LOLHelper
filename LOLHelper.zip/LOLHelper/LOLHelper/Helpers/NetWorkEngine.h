//
//  NetWorkEngine.h
//  FingertipNews
//
//  Created by lanouhn on 15/6/4.
//  Copyright (c) 2015年 Redboyer. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NetWorkEngine;
@protocol dataParserDelegate <NSObject>

//设置代理方法, 当数据请求完毕把data传给代理解析数据
- (void)parserDataWithData:(NSMutableData *)data;
@optional
- (void)failedLoadData;
@end

@interface NetWorkEngine : NSObject
@property (nonatomic, assign) id<dataParserDelegate>delegate;

- (void)loadDataWithString:(NSString *)string;
@end
