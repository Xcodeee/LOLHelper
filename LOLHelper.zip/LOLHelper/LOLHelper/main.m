//
//  main.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/7.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
