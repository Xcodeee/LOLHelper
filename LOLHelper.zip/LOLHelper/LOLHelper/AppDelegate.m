//
//  AppDelegate.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/7.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "AppDelegate.h"
#import "RootTabBarController.h"
#import "Reachability.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
       
    RootTabBarController *root = [[RootTabBarController alloc] init];
    //设置导航视图控制器
    UINavigationController *navigationNC = [[UINavigationController alloc]initWithRootViewController:root];
    self.window.rootViewController = navigationNC;
    [navigationNC setNavigationBarHidden:YES animated:YES]; // 不隐藏导航栏
    

    
    //去掉"back"文字
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(0, -60) forBarMetrics:UIBarMetricsDefault];
    
    
#pragma mark -- 网络请求判断
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkStateChange) name:kReachabilityChangedNotification object:nil];
    self.conn = [Reachability reachabilityForInternetConnection];
    //输出当前网络状态
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.conn.currentReachabilityString  message:nil delegate:self  cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
    [alert show];
    [self.conn startNotifier];
    
    return YES;
}
- (void)networkStateChange {
    [self checkNetworkState];
}

- (void)checkNetworkState {
    //1.检测手机是否能上网
    Reachability *wifi = [Reachability reachabilityForLocalWiFi];
    
    //2.检测手机是否能上网
    Reachability *conn = [Reachability reachabilityForInternetConnection];
    
    //3.判断网络状态
    if ([wifi currentReachabilityStatus]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"有WiFi可用"  message:nil delegate:self  cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        [alert show];
    } else if ([conn currentReachabilityStatus] != NotReachable) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"请使用蜂窝移动网络"  message:nil delegate:self  cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        [alert show];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"没有可用网络"  message:nil delegate:self  cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        [alert show];
    }
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
