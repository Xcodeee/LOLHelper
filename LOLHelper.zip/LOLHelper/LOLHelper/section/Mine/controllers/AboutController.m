//
//  AboutController.m
//  UltronNews
//
//  Created by lanouhn on 15/6/17.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "AboutController.h"
#import "AboutView.h"
@interface AboutController ()
@property (nonatomic, retain) AboutView *aboutView;
@end

@implementation AboutController
- (void)loadView {
    self.aboutView = [[AboutView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.view = _aboutView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}



@end
