//
//  AboutView.m
//  UltronNews
//
//  Created by lanouhn on 15/6/17.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "AboutView.h"
#import "AllMacros.h"
#define kMarginLeft_LB1  15
#define kMarginTop_LB1   30
#define kWidth_LB1       80
#define kheight_LB1      40

#define kMarginLeft_TF1 kMarginLeft_LB1 + kWidth_LB1 + 10
#define kMarginTop_TF1  kMarginTop_LB1
#define kWidth_TF1      kScreenWidth - kMarginLeft_LB1 - kWidth_LB1 - 25
#define kheight_TF1     kheight_LB1


@implementation AboutView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.contentSize = CGSizeMake(kScreenWidth, kScreenHeight + 200);
        self.backgroundColor = [UIColor whiteColor];
        [self layoutAllViews];
    }
    return self;
}

- (void)layoutAllViews {
    //布局简介
    //标签:
    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_LB1, kMarginTop_LB1, kWidth_LB1, kheight_LB1)];
    label1.textAlignment = NSTextAlignmentCenter;
    label1.text = @"软件名称:";
    label1.backgroundColor = [UIColor whiteColor];
    [self addSubview:label1];

    
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_LB1, kMarginTop_LB1 + 60, kWidth_LB1, kheight_LB1)];
    label2.textAlignment = NSTextAlignmentCenter;
    label2.text = @"开发人员:";
    label2.backgroundColor = [UIColor whiteColor];
    [self addSubview:label2];

    
    UILabel *label3 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_LB1, kMarginTop_LB1 + 120, kWidth_LB1, kheight_LB1)];
    label3.textAlignment = NSTextAlignmentCenter;
    label3.text = @"软件功能:";
    label3.backgroundColor = [UIColor whiteColor];
    [self addSubview:label3];

    
    UILabel *label4 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_LB1, kMarginTop_LB1 + 240, kWidth_LB1, kheight_LB1)];
    label4.textAlignment = NSTextAlignmentCenter;
    label4.text = @"开发时间:";
    label4.backgroundColor = [UIColor whiteColor];
    [self addSubview:label4];

    
    UILabel *label5 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_LB1, kMarginTop_LB1 + 300, kWidth_LB1, kheight_LB1)];
    label5.textAlignment = NSTextAlignmentCenter;
    label5.text = @"免责声明:";
    label5.backgroundColor = [UIColor whiteColor];
    [self addSubview:label5];


    
    
    //文本框
    UILabel *tf = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_TF1, kMarginTop_TF1, kWidth_TF1, kheight_TF1)];
    tf.backgroundColor = [UIColor whiteColor];
  //  tf.textAlignment = NSTextAlignmentCenter;
    tf.text = @"LOL微盒子";
    [self addSubview:tf];

    
    UILabel *tf1 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_TF1, kMarginTop_TF1 + 60, kWidth_TF1, kheight_TF1)];
    tf1.backgroundColor = [UIColor whiteColor];
  //  tf1.textAlignment = NSTextAlignmentCenter;
    tf1.text = @"霍佳磊";
    [self addSubview:tf1];

    
    UILabel *tf2 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_TF1, kMarginTop_TF1 + 90, kWidth_TF1, kheight_TF1 + 80)];
    tf2.backgroundColor = [UIColor whiteColor];
    tf2.numberOfLines = 0;
   // tf2.textAlignment = NSTextAlignmentCenter;
    tf2.text = @"LOL微盒子具有关于英雄联盟最新资讯,赛事以及官方通告等文字和视频类型的资讯,并且具有查看所有英雄的使用技巧,对抗技巧,以及英雄的所有技能详解.本软件适合玩家不论是闲暇时间还是游戏时具有很大帮助作用.";
    [self addSubview:tf2];

    
    UILabel *tf3 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_TF1, kMarginTop_TF1 + 240, kWidth_TF1, kheight_TF1)];
    tf3.backgroundColor = [UIColor whiteColor];
//  tf3.textAlignment = NSTextAlignmentCenter;
    tf3.text = @"2015 年 7 月 20 日";
    [self addSubview:tf3];

    
    UILabel *tf4 = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_TF1, kMarginTop_TF1 + 280, kWidth_TF1, kheight_TF1 + 210)];
    tf4.backgroundColor = [UIColor whiteColor];
    tf4.numberOfLines = 0;
    tf4.text = @"LoLHelper(LOL微盒子)的所有权归霍佳磊(作者)拥有,本软件仅用于学习交流,用户不得利用本软件从事非法用途,用户使用本软件必须遵守国家的有关法律法规.本软件对任何直接、间接、偶然、特殊及继起的损害以及引起的经济和法律上的纠纷,创作者不需要负任何责任。";
    [self addSubview:tf4];

    
}







@end
