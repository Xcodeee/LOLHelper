//
//  MineCell.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/15.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MineCell : UITableViewCell
@property (nonatomic, retain) UILabel *aLabel;
@property (nonatomic, retain) UIImageView *picture;
@property (nonatomic, retain) UILabel *suggestLabel;
@end
