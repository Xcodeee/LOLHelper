//
//  MineCell.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/15.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "MineCell.h"
#import "AllMacros.h"

#define kLeft_picture               10
#define kTop_picture                5
#define kWidth_picture              50
#define kHeight_picture             50

#define kLeft_aLabel                (kLeft_picture + kWidth_picture)
#define kTop_aLabel                 kTop_picture
#define kWidth_aLabel               70
#define kHeight_aLabel              kHeight_picture

#define kLeft_suggestLabel                (kLeft_aLabel + kWidth_aLabel + 20)
#define kTop_suggestLabel                 kTop_picture
#define kWidth_suggestLabel               kScreenWidth - kLeft_suggestLabel
#define kHeight_suggestLabel              kHeight_picture


@implementation MineCell

- (UIImageView *)picture {
    if (!_picture) {
        self.picture = [[UIImageView alloc] initWithFrame:CGRectMake(kLeft_picture, kTop_picture, kWidth_picture, kHeight_picture)];
    }
    return _picture;
}


- (UILabel *)aLabel {
    if (!_aLabel) {
        self.aLabel = [[UILabel alloc] initWithFrame:CGRectMake(kLeft_aLabel, kTop_aLabel, kWidth_aLabel, kHeight_aLabel)];
        _aLabel.textColor = [UIColor grayColor];
    }
    return _aLabel;
}
- (UILabel *)suggestLabel {
    if (!_suggestLabel) {
        self.suggestLabel = [[UILabel alloc] initWithFrame:CGRectMake(kLeft_suggestLabel, kTop_suggestLabel, kWidth_suggestLabel, kHeight_suggestLabel)];
        _suggestLabel.textColor = [UIColor grayColor];
    }
    return _suggestLabel;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {//添加子控件
        [self.contentView addSubview:self.aLabel];
        [self.contentView addSubview:self.picture];
        [self.contentView addSubview:self.suggestLabel];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}



@end
