//
//  AboutView.h
//  UltronNews
//
//  Created by lanouhn on 15/6/17.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutView : UIScrollView

@end
