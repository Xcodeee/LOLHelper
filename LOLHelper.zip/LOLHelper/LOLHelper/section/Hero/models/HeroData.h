//
//  HeroData.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/15.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HeroData : NSObject

@property (nonatomic, copy) NSString *nick;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *tag1;
@property (nonatomic, copy) NSString *tag2;
@property (nonatomic, copy) NSString *en_name;  //用于获取对应头像
@property (nonatomic, copy) NSString *id;  //英雄id

//详情
@property (nonatomic, copy) NSString *op_skill;     //操作技巧详情
@property (nonatomic, copy) NSString *teamwork;     //团战思路详情
@property (nonatomic, copy) NSString *use_skill1;   //使用技巧详情1
@property (nonatomic, copy) NSString *use_skill2;   //使用技巧详情2
@property (nonatomic, copy) NSString *use_skill3;   //使用技巧详情3
@property (nonatomic, copy) NSString *ag_skill1;    //对抗技巧详情1
@property (nonatomic, copy) NSString *ag_skill2;    //对抗技巧详情2
@property (nonatomic, copy) NSString *ag_skill3;    //对抗技巧详情3

//技能
@property (nonatomic, copy) NSString *skill1;       //技能图片1|技能名字
@property (nonatomic, copy) NSString *skill2;       //技能图片2|技能名字
@property (nonatomic, copy) NSString *skill3;       //技能图片3|技能名字
@property (nonatomic, copy) NSString *skill4;       //技能图片4|技能名字
@property (nonatomic, copy) NSString *skill5;       //技能图片5|技能名字
@property (nonatomic, copy) NSString *skill1_desc;  //技能描述
@property (nonatomic, copy) NSString *skill2_desc;  //技能描述
@property (nonatomic, copy) NSString *skill3_desc;  //技能描述
@property (nonatomic, copy) NSString *skill4_desc;  //技能描述
@property (nonatomic, copy) NSString *skill5_desc;  //技能描述
@property (nonatomic, copy) NSString *skill2_cooling;  //技能冷却
@property (nonatomic, copy) NSString *skill3_cooling;  //技能冷却
@property (nonatomic, copy) NSString *skill4_cooling;  //技能冷却
@property (nonatomic, copy) NSString *skill5_cooling;  //技能冷却
@property (nonatomic, copy) NSString *skill2_expend;  //技能消耗
@property (nonatomic, copy) NSString *skill3_expend;  //技能消耗
@property (nonatomic, copy) NSString *skill4_expend;  //技能消耗
@property (nonatomic, copy) NSString *skill5_expend;  //技能消耗
@property (nonatomic, copy) NSString *story;           //背景故事
- (id)initWithDictionary:(NSDictionary *)dic;
+ (id)newsDataWithDictionary:(NSDictionary *)dic;   //便利构造器
@end
