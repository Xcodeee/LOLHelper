//
//  HeroData.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/15.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "HeroData.h"

@implementation HeroData

- (id)initWithDictionary:(NSDictionary *)dic {
    self = [super init];
    if (self) {
        //KVC赋值
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

//便利构造器
+ (id)newsDataWithDictionary:(NSDictionary *)dic {
    return [[self alloc] initWithDictionary:dic];
}

//未使用的key调用这个方法
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}


@end
