//
//  HeroDetailController.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/16.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeroData.h"

@interface HeroDetailController : UIViewController
//@property (nonatomic, copy) NSString *enname;      //英雄名字,用于拼接图片网址
//@property (nonatomic, copy) NSString *heroID;//英雄ID,用于拼接详情网址
@property (nonatomic, strong) HeroData *heroDta;    //model

@end

