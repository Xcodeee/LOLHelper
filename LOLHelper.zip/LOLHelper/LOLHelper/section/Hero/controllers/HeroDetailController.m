//
//  HeroDetailController.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/16.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "HeroDetailController.h"
#import "HeroDetail.h"
#import "HeroData.h"
#import "AllMacros.h"

@interface HeroDetailController () 
@property (nonatomic, strong) HeroDetail *heroDetailView;   //给detailController指定根视图
@property (nonatomic, strong) NSMutableArray *datasourc;

@end

@implementation HeroDetailController
//指定根视图
- (void)loadView {
    self.heroDetailView = [[HeroDetail alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.view = self.heroDetailView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
 
    [self passValue];
}

//传值
- (void)passValue {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://ossweb-img.qq.com/upload/qqtalk/lol_hero/hero_%@.js", self.heroDta.id]];
    
    //网络请求
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];


    HeroData *heroData = [[HeroData alloc] init];
    //数据放到model中
    [heroData  setValuesForKeysWithDictionary:dic];

    //传值
    [self.heroDetailView configureItemWithInfo:heroData];
   
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
