//
//  HeroCell.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/15.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeroData.h"
//@class HeroData;
@interface HeroCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *nickLabel;   //称号如"堕落天使"
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *tagLabel;    //职业

//赋值方法
- (void)configureCellWithModel:(HeroData *)heroData;

@end
