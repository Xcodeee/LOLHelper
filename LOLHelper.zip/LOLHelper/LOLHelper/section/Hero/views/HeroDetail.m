//
//  HeroDetail.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/16.
//  Copyright (c) 2015年 HJL. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "HeroDetail.h"
#import "UIImageView+WebCache.h"
#import "AllMacros.h"
#import "HeroData.h"


#define kMarginLeft_detailScroll               0
#define kMarginTop_detailScroll                0
#define kWidth_detailScroll                    kScreenWidth
#define kHeight_detailScroll                   kScreenHeight

#define kMarginLeft_bgPicView                  0
#define kMarginTop_bgPicView                   0
#define kWidth_bgPicView                       kScreenWidth
#define kHeight_bgPicView                      kScreenHeight / 3
//分段scroll导航
#define kMarginLeft_segmentScroll              0
#define kMarginTop_segmentScroll               kHeight_bgPicView
#define kWidth_segmentScroll                   kScreenWidth
#define kHeight_segmentScroll                  40
//分段contentscroll导航内容
#define kMarginLeft_segmentContentScroll       0
#define kMarginTop_segmentContentScroll        kMarginTop_segmentScroll + 40
#define kWidth_segmentContentScroll            kScreenWidth
#define kHeight_segmentContentScroll           (kScreenHeight - kHeight_bgPicView - kHeight_segmentScroll - 64 - 50)

//操作技巧
#define kMarginLeft_opskillLabel               20
#define kMarginTop_opskillLabel                10
#define kWidth_opskillLabel                    kScreenWidth - 30
#define kHeight_opskillLabel                   20
//操作技巧详情
#define kMarginLeft_opskillDetail              20
#define kMarginTop_opskillDetail               kMarginTop_opskillLabel + kHeight_opskillLabel + 5
#define kWidth_opskillDetail                   kScreenWidth - 30
#define kHeight_opskillDetail                  OPSKheight
//团战技巧
#define kMarginTop_teamworkLabel               kMarginTop_opskillDetail + OPSKheight + 10
//团战技巧详情
#define kMarginTop_teamworkDetail              kMarginTop_teamworkLabel + 20 + 5
#define kHeight_teamworkDetail                 TMWKheight

//使用技巧
#define kMarginTop_useskillLabel                kMarginTop_teamworkDetail + kHeight_teamworkDetail+10
//使用技巧详情1
#define kMarginTop_useskillDetail1              kMarginTop_useskillLabel + 20 + 5
#define kHeight_useskillDetail1                 USK1height
//使用技巧详情2
#define kMarginTop_useskillDetail2              kMarginTop_useskillDetail1 + USK1height
#define kHeight_useskillDetail2                 USK2height
//使用技巧详情1
#define kMarginTop_useskillDetail3              kMarginTop_useskillDetail2 + USK2height
#define kHeight_useskillDetail3                 USK3height

//对战技巧
#define kMarginTop_agskillLabel                 kMarginTop_useskillDetail3 + kHeight_useskillDetail3 + 10
//对战技巧详情1
#define kMarginTop_agskillDetail1               kMarginTop_agskillLabel + 20 + 5
#define kHeight_agskillDetail1                  AGSK1height
//对战技巧详情2
#define kMarginTop_agskillDetail2               kMarginTop_agskillDetail1 + AGSK1height
#define kHeight_agskillDetail2                  AGSK2height
//对战技巧详情3
#define kMarginTop_agskillDetail3               kMarginTop_agskillDetail2 + AGSK2height
#define kHeight_agskillDetail3                  AGSK3height

//英雄技能1
#define kMarginLeft_skill1View               kScreenWidth + 20
#define kMarginTop_skill1View                10
#define kWidth_skill1View                    50
#define kHeight_skill1View                   50
//名字1
#define kMarginLeft_skillNameLabel1          kScreenWidth + 20 + kWidth_skill1View
#define kMarginTop_skillNameLabel1           20
#define kWidth_skillNameLabel1               200
#define kHeight_skillNameLabel1              20
//技能描述1
#define kMarginLeft_skill1desc               kScreenWidth + 20
#define kMarginTop_skill1desc                10 +kHeight_skill1View +20
#define kWidth_skill1desc                    kScreenWidth - 30
#define kHeight_skill1desc                   SK1desc
//英雄技能2
#define kMarginLeft_skill2View               kScreenWidth + 20
#define kMarginTop_skill2View                kMarginTop_skill1desc + kHeight_skill1desc +20
#define kWidth_skill2View                    kWidth_skill1View
#define kHeight_skill2View                   kHeight_skill1View
//名字2Q
#define kMarginLeft_skillNameLabel2          kMarginLeft_skillNameLabel1
#define kMarginTop_skillNameLabel2           (kMarginTop_skill2View + kHeight_skill2View - 20)
#define kWidth_skillNameLabel2               200
#define kHeight_skillNameLabel2              20
//技能描述2
#define kMarginLeft_skill2desc               kScreenWidth + 20
#define kMarginTop_skill2desc                kMarginTop_skillNameLabel2 + kHeight_skillNameLabel2
#define kWidth_skill2desc                    kScreenWidth - 30
#define kHeight_skill2desc                   SK2desc
//冷却2
#define kMarginLeft_skill2cooling            kScreenWidth + 20
#define kMarginTop_skill2cooling             kMarginTop_skill2desc + kHeight_skill2desc
#define kWidth_skill2cooling                 kScreenWidth - 30
#define kHeight_skill2cooling                SK2cool
//消耗2
#define kMarginLeft_skill2expend             kScreenWidth + 20
#define kMarginTop_skill2expend              kMarginTop_skill2cooling + kHeight_skill2cooling
#define kWidth_skill2expend                  kScreenWidth - 30
#define kHeight_skill2expend                 SK2expend
//英雄技能3
#define kMarginLeft_skill3View               kScreenWidth + 20
#define kMarginTop_skill3View                kMarginTop_skill2expend + kHeight_skill2expend + 20
#define kWidth_skill3View                    kWidth_skill1View
#define kHeight_skill3View                   kHeight_skill1View
//名字3W
#define kMarginLeft_skillNameLabel3          kMarginLeft_skillNameLabel1
#define kMarginTop_skillNameLabel3           kMarginTop_skill3View + kHeight_skill3View - 20
#define kWidth_skillNameLabel3               200
#define kHeight_skillNameLabel3              20
//技能描述3
#define kMarginLeft_skill3desc               kScreenWidth + 20
#define kMarginTop_skill3desc                kMarginTop_skillNameLabel3 + kHeight_skillNameLabel3 + 10
#define kWidth_skill3desc                    kScreenWidth - 30
#define kHeight_skill3desc                   SK3desc

//冷却3
#define kMarginLeft_skill3cooling            kScreenWidth + 20
#define kMarginTop_skill3cooling             kMarginTop_skill3desc + kHeight_skill3desc
#define kWidth_skill3cooling                 kScreenWidth - 30
#define kHeight_skill3cooling                SK3cool
//消耗3
#define kMarginLeft_skill3expend             kScreenWidth + 20
#define kMarginTop_skill3expend              kMarginTop_skill3cooling + kHeight_skill3cooling
#define kWidth_skill3expend                  kScreenWidth - 30
#define kHeight_skill3expend                 SK3expend
//英雄技能4
#define kMarginLeft_skill4View               kScreenWidth + 20
#define kMarginTop_skill4View                kMarginTop_skill3expend + kHeight_skill3expend + 20
#define kWidth_skill4View                    kWidth_skill1View
#define kHeight_skill4View                   kHeight_skill1View
//名字4E
#define kMarginLeft_skillNameLabel4          kMarginLeft_skillNameLabel1
#define kMarginTop_skillNameLabel4           kMarginTop_skill4View + kHeight_skill4View - 20
#define kWidth_skillNameLabel4               200
#define kHeight_skillNameLabel4              20
//技能描述4
#define kMarginLeft_skill4desc               kScreenWidth + 20
#define kMarginTop_skill4desc                kMarginTop_skillNameLabel4 + kHeight_skillNameLabel4 +10
#define kWidth_skill4desc                    kScreenWidth - 30
#define kHeight_skill4desc                   SK4desc
//冷却4
#define kMarginLeft_skill4cooling            kScreenWidth + 20
#define kMarginTop_skill4cooling             kMarginTop_skill4desc + kHeight_skill4desc
#define kWidth_skill4cooling                 kScreenWidth - 30
#define kHeight_skill4cooling                SK4cool
//消耗4
#define kMarginLeft_skill4expend             kScreenWidth + 20
#define kMarginTop_skill4expend              kMarginTop_skill4cooling + kHeight_skill4cooling
#define kWidth_skill4expend                  kScreenWidth - 30
#define kHeight_skill4expend                 SK4expend
//英雄技能5
#define kMarginLeft_skill5View               kScreenWidth + 20
#define kMarginTop_skill5View                kMarginTop_skill4expend + kHeight_skill4expend + 20
#define kWidth_skill5View                    kWidth_skill1View
#define kHeight_skill5View                   kHeight_skill1View
//名字5R
#define kMarginLeft_skillNameLabel5          kMarginLeft_skillNameLabel1
#define kMarginTop_skillNameLabel5           kMarginTop_skill5View + kHeight_skill5View -20
#define kWidth_skillNameLabel5               200
#define kHeight_skillNameLabel5              20
//技能描述5
#define kMarginLeft_skill5desc               kScreenWidth + 20
#define kMarginTop_skill5desc                kMarginTop_skillNameLabel5 + kHeight_skillNameLabel5 + 10
#define kWidth_skill5desc                    kScreenWidth - 30
#define kHeight_skill5desc                   SK5desc
//冷却5
#define kMarginLeft_skill5cooling            kScreenWidth + 20
#define kMarginTop_skill5cooling             kMarginTop_skill5desc + kHeight_skill5desc
#define kWidth_skill5cooling                 kScreenWidth - 30
#define kHeight_skill5cooling                SK5cool
//消耗5
#define kMarginLeft_skill5expend             kScreenWidth + 20
#define kMarginTop_skill5expend              kMarginTop_skill5cooling + kHeight_skill5cooling
#define kWidth_skill5expend                  kScreenWidth - 30
#define kHeight_skill5expend                 SK5expend


@interface HeroDetail () <UIScrollViewDelegate>

@end
@implementation HeroDetail
#pragma mark - lazy load
//图片
- (UIImageView *)bgPicView {
    if (!_bgPicView) {
        self.bgPicView = [[UIImageView alloc] initWithFrame:CGRectMake(kMarginLeft_bgPicView, kMarginTop_bgPicView, kWidth_bgPicView, kHeight_bgPicView)];

    }
    return _bgPicView;
}
- (UIScrollView *)detailScroll {
    if (!_detailScroll) {
        self.detailScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(kMarginLeft_detailScroll, kMarginTop_detailScroll, kWidth_detailScroll, kHeight_detailScroll)];
        self.detailScroll.backgroundColor = [UIColor whiteColor];
        self.detailScroll.contentSize = CGSizeMake(kScreenWidth, kScreenHeight);
        self.detailScroll.showsVerticalScrollIndicator = NO;
        self.detailScroll.scrollEnabled = NO;
    }
    return _detailScroll;
}
- (UIScrollView *)segmentScroll {
    if (!_segmentScroll) {
        self.segmentScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(kMarginLeft_segmentScroll, kMarginTop_segmentScroll, kWidth_segmentScroll, kHeight_segmentScroll)];

        self.segmentScroll.showsVerticalScrollIndicator = NO;
        
        _skillBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        _spellBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        _skillBtn.frame = CGRectMake(0, 0, kScreenWidth / 2, kHeight_segmentScroll);
        _spellBtn.frame = CGRectMake(kScreenWidth / 2, 0, kScreenWidth / 2, kHeight_segmentScroll);
        [_skillBtn setTitle:@"英雄小技巧" forState:UIControlStateNormal];
        [_spellBtn setTitle:@"技能详情" forState:UIControlStateNormal];
        [_skillBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [_spellBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];

        //设置按钮字体大小
//        skillBtn.titleLabel.font = [UIFont systemFontOfSize:20];
//        spellBtn.titleLabel.font = [UIFont systemFontOfSize:20];
        _skillBtn.tag = 100;
        _spellBtn.tag = 101;
        
        [_skillBtn addTarget:self action:@selector(handleSkillBtn:) forControlEvents:UIControlEventTouchUpInside];
        [_spellBtn addTarget:self action:@selector(handleSpellBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self.segmentScroll addSubview:_skillBtn];
        [self.segmentScroll addSubview:_spellBtn];
    }
    return _segmentScroll;
}
- (UIScrollView *)segmentContentScroll {
    if (!_segmentContentScroll) {
        self.segmentContentScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(kMarginLeft_segmentContentScroll, kMarginTop_segmentContentScroll, kWidth_segmentContentScroll, kHeight_segmentContentScroll)];
        self.segmentContentScroll.backgroundColor = [UIColor whiteColor];
        self.segmentContentScroll.showsVerticalScrollIndicator = NO;
        self.segmentContentScroll.showsHorizontalScrollIndicator = NO;
        self.segmentContentScroll.contentSize = CGSizeMake(kScreenWidth * 2, kScreenHeight * 2);
        //整屏滚动
        self.segmentContentScroll.pagingEnabled = YES;
        //设置滑动时的方向锁(只能滑动一个方向)
        self.segmentContentScroll.directionalLockEnabled = YES;
    }
    return _segmentContentScroll;
}
//*操作技巧
- (UILabel *)opskillLabel {
    if (!_opskillLabel) {
        self.opskillLabel = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_opskillLabel, kMarginTop_opskillLabel, kWidth_opskillLabel, kHeight_opskillLabel)];
        self.opskillLabel.text = @"操作技巧";
        [self.opskillLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:15]];
    }
    return _opskillLabel;
}
//操作技巧详情
- (UILabel *)opskillDetail {
    if (!_opskillDetail) {
        //计算高度
        self.opskillDetail = [[UILabel alloc] init];
        self.opskillDetail.font = [UIFont systemFontOfSize:13];
        [self.opskillDetail setNumberOfLines:0];
    }
    return _opskillDetail;
}
//*团战思路
- (UILabel *)teamworkLabel {
    if (!_teamworkLabel) {
        self.teamworkLabel = [[UILabel alloc] init];
        self.teamworkLabel.text = @"团战思路";
        [self.teamworkLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:15]];
    }
    return _teamworkLabel;
}
//团战思路详情
- (UILabel *)teamworkDetail {
    if (!_teamworkDetail) {
        self.teamworkDetail = [[UILabel alloc] init];
        self.teamworkDetail.font = [UIFont systemFontOfSize:13];
        [self.teamworkDetail setNumberOfLines:0];
    }
    return _teamworkDetail;
}
//*使用技巧
- (UILabel *)useskillLabel {
    if (!_useskillLabel) {
        self.useskillLabel = [[UILabel alloc] init];
        self.useskillLabel.text = @"使用技巧";
        [self.useskillLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:15]];
    }
    return _useskillLabel;
}
//使用技巧详情123
- (UILabel *)useskillDetail1 {
    if (!_useskillDetail1) {
        self.useskillDetail1 = [[UILabel alloc] init];
        self.useskillDetail1.font = [UIFont systemFontOfSize:13];
        [self.useskillDetail1 setNumberOfLines:0];
    }
    return _useskillDetail1;
}
- (UILabel *)useskillDetail2 {
    if (!_useskillDetail2) {
        self.useskillDetail2 = [[UILabel alloc] init];
        self.useskillDetail2.font = [UIFont systemFontOfSize:13];
        [self.useskillDetail2 setNumberOfLines:0];
    }
    return _useskillDetail2;
}
- (UILabel *)useskillDetail3 {
    if (!_useskillDetail3) {
        self.useskillDetail3 = [[UILabel alloc] init];
        self.useskillDetail3.font = [UIFont systemFontOfSize:13];
        [self.useskillDetail3 setNumberOfLines:0];
    }
    return _useskillDetail3;
}
//*对抗技巧
- (UILabel *)agskillLabel {
    if (!_agskillLabel) {
        self.agskillLabel = [[UILabel alloc] init];
        self.agskillLabel.text = @"对抗技巧";
        [self.agskillLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:15]];
    }
    return _agskillLabel;
}
//对抗技巧详情
- (UILabel *)agskillDetail1 {
    if (!_agskillDetail1) {
        self.agskillDetail1 = [[UILabel alloc] init];
        self.agskillDetail1.font = [UIFont systemFontOfSize:13];
        [self.agskillDetail1 setNumberOfLines:0];
    }
    return _agskillDetail1;
}
- (UILabel *)agskillDetail2 {
    if (!_agskillDetail2) {
        self.agskillDetail2 = [[UILabel alloc] init];
        self.agskillDetail2.font = [UIFont systemFontOfSize:13];
        [self.agskillDetail2 setNumberOfLines:0];
    }
    return _agskillDetail2;
}
- (UILabel *)agskillDetail3 {
    if (!_agskillDetail3) {
        self.agskillDetail3 = [[UILabel alloc] init];
        self.agskillDetail3.font = [UIFont systemFontOfSize:13];
        [self.agskillDetail3 setNumberOfLines:0];
    }
    return _agskillDetail3;
}

//英雄技能图片1
- (UIImageView *)skill1View {
    if (!_skill1View) {
        self.skill1View = [[UIImageView alloc] init];
    }
    return _skill1View;
}
//技能名字1
- (UILabel *)skillNameLabel1 {
    if (!_skillNameLabel1) {
        self.skillNameLabel1 = [[UILabel alloc] init];
        self.skillNameLabel1.font = [UIFont systemFontOfSize:13];
    }
    return _skillNameLabel1;
}
//技能描述1
- (UILabel *)skill1desc {
    if (!_skill1desc) {
        self.skill1desc = [[UILabel alloc] init];
        self.skill1desc.font = [UIFont systemFontOfSize:13];
        [self.skill1desc setNumberOfLines:0];
    }
    return _skill1desc;
}

//英雄技能图片2
- (UIImageView *)skill2View {
    if (!_skill2View) {
        self.skill2View = [[UIImageView alloc] init];
    }
    return _skill2View;
}
//技能名字2
- (UILabel *)skillNameLabel2 {
    if (!_skillNameLabel2) {
        self.skillNameLabel2 = [[UILabel alloc] init];
        self.skillNameLabel2.font = [UIFont systemFontOfSize:13];
    }
    return _skillNameLabel2;
}
//技能描述2
- (UILabel *)skill2desc {
    if (!_skill2desc) {
        self.skill2desc = [[UILabel alloc] init];
        self.skill2desc.font = [UIFont systemFontOfSize:13];
        [self.skill2desc setNumberOfLines:0];
    }
    return _skill2desc;
}
//技能冷却2
- (UILabel *)skill2cooling {
    if (!_skill2cooling) {
        self.skill2cooling = [[UILabel alloc] init];
        self.skill2cooling.font = [UIFont systemFontOfSize:13];
        [self.skill2cooling setNumberOfLines:0];
    }
    return _skill2cooling;
}
//技能消耗2
- (UILabel *)skill2expend {
    if (!_skill2expend) {
        self.skill2expend = [[UILabel alloc] init];
        self.skill2expend.font = [UIFont systemFontOfSize:13];
        [self.skill2expend setNumberOfLines:0];
    }
    return _skill2expend;
}

//英雄技能图片3
- (UIImageView *)skill3View {
    if (!_skill3View) {
        self.skill3View = [[UIImageView alloc] init];
    }
    return _skill3View;
}
//技能名字3
- (UILabel *)skillNameLabel3 {
    if (!_skillNameLabel3) {
        self.skillNameLabel3 = [[UILabel alloc] init];
        self.skillNameLabel3.font = [UIFont systemFontOfSize:13];
    }
    return _skillNameLabel3;
}
//技能描述3
- (UILabel *)skill3desc {
    if (!_skill3desc) {
        self.skill3desc = [[UILabel alloc] init];
        self.skill3desc.font = [UIFont systemFontOfSize:13];
        [self.skill3desc setNumberOfLines:0];
    }
    return _skill3desc;
}
//技能冷却3
- (UILabel *)skill3cooling {
    if (!_skill3cooling) {
        self.skill3cooling = [[UILabel alloc] init];
        self.skill3cooling.font = [UIFont systemFontOfSize:13];
        [self.skill3cooling setNumberOfLines:0];
    }
    return _skill3cooling;
}
//技能消耗3
- (UILabel *)skill3expend {
    if (!_skill3expend) {
        self.skill3expend = [[UILabel alloc] init];
        self.skill3expend.font = [UIFont systemFontOfSize:13];
        [self.skill3expend setNumberOfLines:0];
    }
    return _skill3expend;
}

//英雄技能图片4
- (UIImageView *)skill4View {
    if (!_skill4View) {
        self.skill4View = [[UIImageView alloc] init];
    }
    return _skill4View;
}
//技能名字4
- (UILabel *)skillNameLabel4 {
    if (!_skillNameLabel4) {
        self.skillNameLabel4 = [[UILabel alloc] init];
        self.skillNameLabel4.font = [UIFont systemFontOfSize:13];
    }
    return _skillNameLabel4;
}
//技能描述4
- (UILabel *)skill4desc {
    if (!_skill4desc) {
        self.skill4desc = [[UILabel alloc] init];
        self.skill4desc.font = [UIFont systemFontOfSize:13];
        [self.skill4desc setNumberOfLines:0];
    }
    return _skill4desc;
}
//技能冷却4
- (UILabel *)skill4cooling {
    if (!_skill4cooling) {
        self.skill4cooling = [[UILabel alloc] init];
        self.skill4cooling.font = [UIFont systemFontOfSize:13];
        [self.skill4cooling setNumberOfLines:0];
    }
    return _skill4cooling;
}
//技能消耗4
- (UILabel *)skill4expend {
    if (!_skill4expend) {
        self.skill4expend = [[UILabel alloc] init];
        self.skill4expend.font = [UIFont systemFontOfSize:13];
        [self.skill4expend setNumberOfLines:0];
    }
    return _skill4expend;
}

//英雄技能图片5
- (UIImageView *)skill5View {
    if (!_skill5View) {
        self.skill5View = [[UIImageView alloc] init];
    }
    return _skill5View;
}
//技能名字5
- (UILabel *)skillNameLabel5 {
    if (!_skillNameLabel5) {
        self.skillNameLabel5 = [[UILabel alloc] init];
        self.skillNameLabel5.font = [UIFont systemFontOfSize:13];
    }
    return _skillNameLabel5;
}
//技能描述5
- (UILabel *)skill5desc {
    if (!_skill5desc) {
        self.skill5desc = [[UILabel alloc] init];
        self.skill5desc.font = [UIFont systemFontOfSize:13];
        [self.skill5desc setNumberOfLines:0];
    }
    return _skill5desc;
}
//技能冷却5
- (UILabel *)skill5cooling {
    if (!_skill5cooling) {
        self.skill5cooling = [[UILabel alloc] init];
        self.skill5cooling.font = [UIFont systemFontOfSize:13];
        [self.skill5cooling setNumberOfLines:0];
    }
    return _skill5cooling;
}
//技能消耗5
- (UILabel *)skill5expend {
    if (!_skill5expend) {
        self.skill5expend = [[UILabel alloc] init];
        self.skill5expend.font = [UIFont systemFontOfSize:13];
        [self.skill5expend setNumberOfLines:0];
    }
    return _skill5expend;
}



//cell的初始化方法
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        //添加控件
        [self addSubview:self.detailScroll];
        [self.detailScroll addSubview:self.bgPicView];
        [self.detailScroll addSubview:self.segmentScroll];
        [self.detailScroll addSubview:self.segmentContentScroll];
        //技巧
        [self.segmentContentScroll addSubview:self.opskillLabel];
        [self.segmentContentScroll addSubview:self.opskillDetail];
        [self.segmentContentScroll addSubview:self.teamworkLabel];
        [self.segmentContentScroll addSubview:self.teamworkDetail];
        [self.segmentContentScroll addSubview:self.useskillLabel];
        [self.segmentContentScroll addSubview:self.useskillDetail1];
        [self.segmentContentScroll addSubview:self.useskillDetail2];
        [self.segmentContentScroll addSubview:self.useskillDetail3];
        [self.segmentContentScroll addSubview:self.agskillLabel];
        [self.segmentContentScroll addSubview:self.agskillDetail1];
        [self.segmentContentScroll addSubview:self.agskillDetail2];
        [self.segmentContentScroll addSubview:self.agskillDetail3];
        //技能
        [self.segmentContentScroll addSubview:self.skill1View];
        [self.segmentContentScroll addSubview:self.skill2View];
        [self.segmentContentScroll addSubview:self.skill3View];
        [self.segmentContentScroll addSubview:self.skill4View];
        [self.segmentContentScroll addSubview:self.skill5View];
        [self.segmentContentScroll addSubview:self.skillNameLabel1];
        [self.segmentContentScroll addSubview:self.skillNameLabel2];
        [self.segmentContentScroll addSubview:self.skillNameLabel3];
        [self.segmentContentScroll addSubview:self.skillNameLabel4];
        [self.segmentContentScroll addSubview:self.skillNameLabel5];
        [self.segmentContentScroll addSubview:self.skill1desc];
        [self.segmentContentScroll addSubview:self.skill2desc];
        [self.segmentContentScroll addSubview:self.skill3desc];
        [self.segmentContentScroll addSubview:self.skill4desc];
        [self.segmentContentScroll addSubview:self.skill5desc];
        [self.segmentContentScroll addSubview:self.skill2cooling];
        [self.segmentContentScroll addSubview:self.skill3cooling];
        [self.segmentContentScroll addSubview:self.skill4cooling];
        [self.segmentContentScroll addSubview:self.skill5cooling];
        [self.segmentContentScroll addSubview:self.skill2expend];
        [self.segmentContentScroll addSubview:self.skill3expend];
        [self.segmentContentScroll addSubview:self.skill4expend];
        [self.segmentContentScroll addSubview:self.skill5expend];
    }
    return self;
}

- (CGFloat)countTextHeightWithText:(NSString *)str{
    
    NSString *descriptionStr = str;
    CGSize size = CGSizeMake(kScreenWidth, 2000);
    CGSize textSize = [descriptionStr boundingRectWithSize:size  options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:13]} context:nil].size;
    return textSize.height;
}


//赋值方法
- (void)configureItemWithInfo:(HeroData *)heroData {
    self.segmentContentScroll.delegate = self;
    //背景图片
    [self.bgPicView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://down.qq.com/qqtalk/lolApp/images/hero_background/%@_Splash_0.jpg", heroData.en_name]]];
    NSLog(@"---------%@", heroData.id);
    self.opskillDetail.text = heroData.op_skill;
    self.teamworkDetail.text = heroData.teamwork;
    self.useskillDetail1.text = [NSString stringWithFormat:@"%@", heroData.use_skill1];
    self.useskillDetail2.text = [NSString stringWithFormat:@"%@", heroData.use_skill2];
    self.useskillDetail3.text = [NSString stringWithFormat:@"%@", heroData.use_skill3];
    self.agskillDetail1.text = [NSString stringWithFormat:@"%@", heroData.ag_skill1];
    self.agskillDetail2.text = [NSString stringWithFormat:@"%@", heroData.ag_skill2];
    self.agskillDetail3.text = [NSString stringWithFormat:@"%@", heroData.ag_skill3];
    
    [self.skill1View setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@", [heroData.skill1 substringToIndex:[heroData.skill1 rangeOfString:@"|"].location]]]];

    
    [self.skill2View setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@", [heroData.skill2 substringToIndex:[heroData.skill2 rangeOfString:@"|"].location]]]];
    [self.skill3View setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@", [heroData.skill3 substringToIndex:[heroData.skill3 rangeOfString:@"|"].location]]]];
    [self.skill4View setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@", [heroData.skill4 substringToIndex:[heroData.skill4 rangeOfString:@"|"].location]]]];
    [self.skill5View setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@", [heroData.skill5 substringToIndex:[heroData.skill5 rangeOfString:@"|"].location]]]];
    
    self.skillNameLabel1.text = [NSString stringWithFormat:@"%@", [heroData.skill1 substringFromIndex:[heroData.skill1 rangeOfString:@"|"].location + 1]];
    self.skillNameLabel2.text = [NSString stringWithFormat:@"%@", [heroData.skill2 substringFromIndex:[heroData.skill2 rangeOfString:@"|"].location + 1]];
    self.skillNameLabel3.text = [NSString stringWithFormat:@"%@", [heroData.skill3 substringFromIndex:[heroData.skill3 rangeOfString:@"|"].location + 1]];
    self.skillNameLabel4.text = [NSString stringWithFormat:@"%@", [heroData.skill4 substringFromIndex:[heroData.skill4 rangeOfString:@"|"].location + 1]];
    self.skillNameLabel5.text = [NSString stringWithFormat:@"%@", [heroData.skill5 substringFromIndex:[heroData.skill5 rangeOfString:@"|"].location + 1]];
    
    self.skill1desc.text = [NSString stringWithFormat:@"%@", heroData.skill1_desc];
    self.skill2desc.text = [NSString stringWithFormat:@"%@", heroData.skill2_desc];
    self.skill3desc.text = [NSString stringWithFormat:@"%@", heroData.skill3_desc];
    self.skill4desc.text = [NSString stringWithFormat:@"%@", heroData.skill4_desc];
    self.skill5desc.text = [NSString stringWithFormat:@"%@", heroData.skill5_desc];
    
    self.skill2cooling.text = [NSString stringWithFormat:@"%@", heroData.skill2_cooling];
    self.skill3cooling.text = [NSString stringWithFormat:@"%@", heroData.skill3_cooling];
    self.skill4cooling.text = [NSString stringWithFormat:@"%@", heroData.skill4_cooling];
    self.skill5cooling.text = [NSString stringWithFormat:@"%@", heroData.skill5_cooling];
    
    self.skill2expend.text = [NSString stringWithFormat:@"%@", heroData.skill2_expend];
    self.skill3expend.text = [NSString stringWithFormat:@"%@", heroData.skill3_expend];
    self.skill4expend.text = [NSString stringWithFormat:@"%@", heroData.skill4_expend];
    self.skill5expend.text = [NSString stringWithFormat:@"%@", heroData.skill5_expend];
    
    CGFloat OPSKheight = [self countTextHeightWithText:heroData.op_skill];
    CGFloat TMWKheight = [self countTextHeightWithText:heroData.teamwork];
    CGFloat USK1height = [self countTextHeightWithText:heroData.use_skill1];
    CGFloat USK2height = [self countTextHeightWithText:heroData.use_skill2];
    CGFloat USK3height = [self countTextHeightWithText:heroData.use_skill3];
    CGFloat AGSK1height = [self countTextHeightWithText:heroData.ag_skill1];
    CGFloat AGSK2height = [self countTextHeightWithText:heroData.ag_skill2];
    CGFloat AGSK3height = [self countTextHeightWithText:heroData.ag_skill3];
    
    CGFloat SK1desc = [self countTextHeightWithText:heroData.skill1_desc];
    CGFloat SK2desc = [self countTextHeightWithText:heroData.skill2_desc];
    CGFloat SK3desc = [self countTextHeightWithText:heroData.skill3_desc];
    CGFloat SK4desc = [self countTextHeightWithText:heroData.skill4_desc];
    CGFloat SK5desc = [self countTextHeightWithText:heroData.skill5_desc];
    CGFloat SK2cool = [self countTextHeightWithText:heroData.skill2_cooling];
    CGFloat SK3cool = [self countTextHeightWithText:heroData.skill3_cooling];
    CGFloat SK4cool = [self countTextHeightWithText:heroData.skill4_cooling];
    CGFloat SK5cool = [self countTextHeightWithText:heroData.skill5_cooling];
    CGFloat SK2expend = [self countTextHeightWithText:heroData.skill2_expend];
    CGFloat SK3expend = [self countTextHeightWithText:heroData.skill3_expend];
    CGFloat SK4expend = [self countTextHeightWithText:heroData.skill4_expend];
    CGFloat SK5expend = [self countTextHeightWithText:heroData.skill5_expend];
    
    
    self.opskillDetail.frame = CGRectMake(20, kMarginTop_opskillDetail, kWidth_opskillLabel, kHeight_opskillDetail);
    self.teamworkLabel.frame = CGRectMake(20, kMarginTop_teamworkLabel, kWidth_opskillLabel, 20);
    self.teamworkDetail.frame = CGRectMake(20, kMarginTop_teamworkDetail, kWidth_opskillLabel, kHeight_teamworkDetail);
    self.useskillLabel.frame = CGRectMake(20, kMarginTop_useskillLabel, kWidth_opskillLabel, 20);
    //使用详情123
    self.useskillDetail1.frame = CGRectMake(20, kMarginTop_useskillDetail1, kWidth_opskillLabel, kHeight_useskillDetail1);
    self.useskillDetail2.frame = CGRectMake(20, kMarginTop_useskillDetail2, kWidth_opskillLabel, kHeight_useskillDetail2);
    self.useskillDetail3.frame = CGRectMake(20, kMarginTop_useskillDetail3, kWidth_opskillLabel, kHeight_useskillDetail3);
    self.agskillLabel.frame = CGRectMake(20, kMarginTop_agskillLabel, kWidth_opskillLabel, 20);
    //对战详情123
    self.agskillDetail1.frame = CGRectMake(20, kMarginTop_agskillDetail1, kWidth_opskillLabel, kHeight_agskillDetail1);
    self.agskillDetail2.frame = CGRectMake(20, kMarginTop_agskillDetail2, kWidth_opskillLabel, kHeight_agskillDetail2);
    self.agskillDetail3.frame = CGRectMake(20, kMarginTop_agskillDetail3, kWidth_opskillLabel, kHeight_agskillDetail3);
    
    //技能图片
    self.skill1View.frame = CGRectMake(kMarginLeft_skill1View, kMarginTop_skill1View, kWidth_skill1View, kHeight_skill1View);
    self.skill2View.frame = CGRectMake(kMarginLeft_skill2View, kMarginTop_skill2View, kWidth_skill2View, kHeight_skill2View);
    self.skill3View.frame = CGRectMake(kMarginLeft_skill3View, kMarginTop_skill3View, kWidth_skill3View, kHeight_skill3View);
    self.skill4View.frame = CGRectMake(kMarginLeft_skill4View, kMarginTop_skill4View, kWidth_skill4View, kHeight_skill4View);
    self.skill5View.frame = CGRectMake(kMarginLeft_skill5View, kMarginTop_skill5View, kWidth_skill5View, kHeight_skill5View);
    //技能名字
    self.skillNameLabel1.frame = CGRectMake(kMarginLeft_skillNameLabel1, kMarginTop_skillNameLabel1, kWidth_skillNameLabel1, kHeight_skillNameLabel1);
    self.skillNameLabel2.frame = CGRectMake(kMarginLeft_skillNameLabel2, kMarginTop_skillNameLabel2, kWidth_skillNameLabel2, kHeight_skillNameLabel2);
    self.skillNameLabel3.frame = CGRectMake(kMarginLeft_skillNameLabel3, kMarginTop_skillNameLabel3, kWidth_skillNameLabel3, kHeight_skillNameLabel3);
    self.skillNameLabel4.frame = CGRectMake(kMarginLeft_skillNameLabel4, kMarginTop_skillNameLabel4, kWidth_skillNameLabel4, kHeight_skillNameLabel4);
    self.skillNameLabel5.frame = CGRectMake(kMarginLeft_skillNameLabel5, kMarginTop_skillNameLabel5, kWidth_skillNameLabel5, kHeight_skillNameLabel5);
    //技能描述
    self.skill1desc.frame = CGRectMake(kMarginLeft_skill1desc, kMarginTop_skill1desc, kWidth_skill1desc, kHeight_skill1desc);
    self.skill2desc.frame = CGRectMake(kMarginLeft_skill2desc, kMarginTop_skill2desc, kWidth_skill2desc, kHeight_skill2desc);
    self.skill3desc.frame = CGRectMake(kMarginLeft_skill3desc, kMarginTop_skill3desc, kWidth_skill3desc, kHeight_skill3desc);
    self.skill4desc.frame = CGRectMake(kMarginLeft_skill4desc, kMarginTop_skill4desc, kWidth_skill4desc, kHeight_skill4desc);
    self.skill5desc.frame = CGRectMake(kMarginLeft_skill5desc, kMarginTop_skill5desc, kWidth_skill5desc, kHeight_skill5desc);
    //技能冷却
    self.skill2cooling.frame = CGRectMake(kMarginLeft_skill2cooling, kMarginTop_skill2cooling, kWidth_skill2cooling, kHeight_skill2cooling);
    self.skill3cooling.frame = CGRectMake(kMarginLeft_skill3cooling, kMarginTop_skill3cooling, kWidth_skill3cooling, kHeight_skill3cooling);
    self.skill4cooling.frame = CGRectMake(kMarginLeft_skill4cooling, kMarginTop_skill4cooling, kWidth_skill4cooling, kHeight_skill4cooling);
    self.skill5cooling.frame = CGRectMake(kMarginLeft_skill5cooling, kMarginTop_skill5cooling, kWidth_skill5cooling, kHeight_skill5cooling);
    //技能消耗
    self.skill2expend.frame = CGRectMake(kMarginLeft_skill2expend, kMarginTop_skill2expend, kWidth_skill2expend, kHeight_skill2expend);
    self.skill3expend.frame = CGRectMake(kMarginLeft_skill3expend, kMarginTop_skill3expend, kWidth_skill3expend, kHeight_skill3expend);
    self.skill4expend.frame = CGRectMake(kMarginLeft_skill4expend, kMarginTop_skill4expend, kWidth_skill4expend, kHeight_skill4expend);
    self.skill5expend.frame = CGRectMake(kMarginLeft_skill5expend, kMarginTop_skill5expend, kWidth_skill5expend, kHeight_skill5expend);
    
}
#pragma mark - UIScrollViewDelegate
//触发时机:scrollView结束减速时触发.(该方法不一定触发)
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    //获得当前contentTableView的页数
    NSInteger ofSet = self.segmentContentScroll.contentOffset.x  / kScreenWidth;
    NSLog(@"%ld", ofSet);
        if (ofSet == 0) {
            [_skillBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        } else {
            [_skillBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        }
    if (ofSet == 1) {
        [_spellBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    } else {
        [_spellBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    }
}

#pragma mark - handleAction
//处理点击频道按钮事件
- (void)handleSkillBtn:(UIButton *)sender {
    NSInteger btnIndex = sender.tag - 100;
    //设置按钮点击颜色
    [_skillBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_spellBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [self.segmentContentScroll setContentOffset:CGPointMake(kScreenWidth * btnIndex, 0) animated:YES];
}
- (void)handleSpellBtn:(UIButton *)sender {
    NSInteger btnIndex = sender.tag - 100;
    //设置按钮点击颜色和偏移量
    [_spellBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_skillBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [self.segmentContentScroll setContentOffset:CGPointMake(kScreenWidth * btnIndex, 0) animated:YES];
}



@end
