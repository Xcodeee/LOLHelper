//
//  HeroCell.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/15.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeroCell.h"
#import "AllMacros.h"

#import "HeroData.h"
#import "SDImageCache.h"
#import "UIImageView+WebCache.h"
#define kItemWidth                  (kScreenWidth / 2 - 30)
#define kItemHeight                 kItemWidth * 2 / 5

#define kImgViewWidth               kItemHeight

#define kNickLabel_left             kImgViewWidth + 5
#define kNickLabel_width            kItemWidth - kNickLabel_left
#define kNickLabel_hight            (kImgViewWidth - 10) / 3


#define kNameLabel_left             kNickLabel_left
#define kNameLabel_Top              kNickLabel_hight + 5
#define kNameLabel_width            kNickLabel_width
#define kNameLabel_hight            kNickLabel_hight

#define ktagLabelLabel_left         kNickLabel_left
#define ktagLabelLabel_Top          kNameLabel_Top + kNickLabel_hight + 5
#define ktagLabelLabel_width        kNickLabel_width
#define ktagLabelLabel_hight        kNickLabel_hight



@implementation HeroCell

- (instancetype)initWithFrame:(CGRect)frame {
    self= [super initWithFrame:frame];
    if (self) {
        //添加子控件
        [self.contentView addSubview:self.imgView];
        [self.contentView addSubview:self.nickLabel];
        [self.contentView addSubview:self.nameLabel];
        [self.contentView addSubview:self.tagLabel];
    }
    return self;
}
//懒加载
- (UIImageView *)imgView {
    if (!_imgView) {
        self.imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kImgViewWidth, kImgViewWidth)];
        _imgView.backgroundColor = [UIColor lightGrayColor];
    }
    return _imgView;
}
- (UILabel *)nickLabel {
    if (!_nickLabel) {
        self.nickLabel = [[UILabel alloc] initWithFrame:CGRectMake(kNickLabel_left, 0, kNickLabel_width, kNickLabel_hight)];
//        _nickLabel.font = [UIFont boldSystemFontOfSize:20];
        _nickLabel.textAlignment = NSTextAlignmentLeft;
    }
    return _nickLabel;
}
- (UILabel *)nameLabel {
    if (!_nameLabel) {
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(kNameLabel_left, kNameLabel_Top, kNameLabel_width, kNameLabel_hight)];
        _nameLabel.font = [UIFont boldSystemFontOfSize:13];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        _nameLabel.textColor = [UIColor grayColor];
    }
    return _nameLabel;
}
- (UILabel *)tagLabel {
    if (!_tagLabel) {
        self.tagLabel = [[UILabel alloc] initWithFrame:CGRectMake(ktagLabelLabel_left, ktagLabelLabel_Top, ktagLabelLabel_width, ktagLabelLabel_hight)];
        _tagLabel.font = [UIFont boldSystemFontOfSize:13];
        _tagLabel.textAlignment = NSTextAlignmentLeft;
        _tagLabel.textColor = [UIColor grayColor];
    }
    return _tagLabel;
}

//赋值方法,存放一条新闻信息
- (void)configureCellWithModel:(HeroData *)heroData {
    //图片,给imgView设置图片
    [self.imgView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@", heroData.en_name]]];
    self.nickLabel.text = heroData.nick;
    self.nameLabel.text = heroData.name;
    self.tagLabel.text = [NSString stringWithFormat:@"%@ / %@", heroData.tag1, heroData.tag2];
}
@end
