//
//  HeroDetail.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/16.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeroData.h"    //获取网址


@interface HeroDetail : UIView

@property (nonatomic, strong) UIImageView *bgPicView;   //图片
@property (nonatomic, strong) UILabel *nameLabel;       //名字
@property (nonatomic, strong) UILabel *tagLabel;        //职业属性
@property (nonatomic, strong) UILabel *priceLabel; //价格
#pragma mark - scrollView
@property (nonatomic ,strong) UIScrollView *detailScroll;   //展示信息的scroll


//存储技巧/技能对象
@property (nonatomic, strong) UIScrollView *segmentScroll;
@property (nonatomic, strong) UIScrollView *segmentContentScroll;

@property (nonatomic, strong) UILabel *opskillLabel;            //操作技巧
@property (nonatomic, strong) UILabel *opskillDetail;           //操作技巧详情
@property (nonatomic, assign) CGFloat *opskillDetailHeight;
@property (nonatomic, strong) UILabel *teamworkLabel;           //团战思路
@property (nonatomic, strong) UILabel *teamworkDetail;          //团战思路详情
@property (nonatomic, strong) UILabel *useskillLabel;           //使用技巧
@property (nonatomic, strong) UILabel *useskillDetail1;         //使用技巧详情1
@property (nonatomic, strong) UILabel *useskillDetail2;         //使用技巧详情2
@property (nonatomic, strong) UILabel *useskillDetail3;         //使用技巧详情3
@property (nonatomic, strong) UILabel *agskillLabel;            //对抗技巧
@property (nonatomic, strong) UILabel *agskillDetail1;          //对抗技巧详情1
@property (nonatomic, strong) UILabel *agskillDetail2;          //对抗技巧详情2
@property (nonatomic, strong) UILabel *agskillDetail3;          //对抗技巧详情3

@property (nonatomic, retain) UIButton *skillBtn;               //"英雄技巧"
@property (nonatomic, retain) UIButton *spellBtn;               //"英雄技能"

@property (nonatomic, strong) UIImageView *skill1View;          //技能1图片
@property (nonatomic, strong) UIImageView *skill2View;          //技能2图片
@property (nonatomic, strong) UIImageView *skill3View;          //技能3图片
@property (nonatomic, strong) UIImageView *skill4View;          //技能4图片
@property (nonatomic, strong) UIImageView *skill5View;          //技能5图片
@property (nonatomic, strong) UILabel *skillNameLabel1;         //技能名字Label
@property (nonatomic, strong) UILabel *skillNameLabel2;         //技能名字Label
@property (nonatomic, strong) UILabel *skillNameLabel3;         //技能名字Label
@property (nonatomic, strong) UILabel *skillNameLabel4;         //技能名字Label
@property (nonatomic, strong) UILabel *skillNameLabel5;         //技能名字Label
@property (nonatomic, strong) UILabel *skill1desc;              //技能描述
@property (nonatomic, strong) UILabel *skill2desc;              //技能描述
@property (nonatomic, strong) UILabel *skill3desc;              //技能描述
@property (nonatomic, strong) UILabel *skill4desc;              //技能描述
@property (nonatomic, strong) UILabel *skill5desc;              //技能描述/////布局玩还有下面两个布局
@property (nonatomic, strong) UILabel *skill2cooling;           //冷却
@property (nonatomic, strong) UILabel *skill3cooling;           //冷却
@property (nonatomic, strong) UILabel *skill4cooling;           //冷却
@property (nonatomic, strong) UILabel *skill5cooling;           //冷却
@property (nonatomic, strong) UILabel *skill2expend;            //消耗
@property (nonatomic, strong) UILabel *skill3expend;            //消耗
@property (nonatomic, strong) UILabel *skill4expend;            //消耗
@property (nonatomic, strong) UILabel *skill5expend;            //消耗


//赋值方法
- (void)configureItemWithInfo:(HeroData *)heroData;
//动态计算label高度
- (CGFloat)countTextHeightWithText:(NSString *)text;
@end
