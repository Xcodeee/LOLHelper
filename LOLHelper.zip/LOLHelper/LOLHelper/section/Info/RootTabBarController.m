//
//  RootTabBarController.m
//  UltronNews
//
//  Created by lanouhn on 15/6/16.
//  Copyright (c) 2015年 HJL. All rights reserved.
//
#import "RootTabBarController.h"
#import "InformationController.h"  //新闻列表界面
#import "HeroController.h"
#import "MineController.h"
#import "AllMacros.h"

@interface RootTabBarController ()

@end

@implementation RootTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    

    
    [self configureTabBarController];
}



//添加tabBarController的Item
- (void)configureTabBarController {
    //资讯
    InformationController *infoVC = [[InformationController alloc] init];
    infoVC.title = @"资讯";
    self.infoNavi = [[UINavigationController alloc] initWithRootViewController:infoVC];
  //点击和不点击的状态都设置为原图像
    self.infoNavi.tabBarItem.selectedImage = [[UIImage imageNamed:@"zixun35*35"] imageWithRenderingMode: UIImageRenderingModeAlwaysOriginal];
    self.infoNavi.tabBarItem.image = [[UIImage imageNamed:@"zixun30*30"] imageWithRenderingMode: UIImageRenderingModeAlwaysOriginal];

    //英雄查询
    HeroController *heroVC = [[HeroController alloc] init];
    heroVC.title = @"英雄资料";
    self.heroNavi = [[UINavigationController alloc] initWithRootViewController:heroVC];
//    UIImage *imag2 = [UIImage imageNamed:@"Ziggs"];
//    self.heroNavi.tabBarItem.image = imag2;
    //点击和不点击的状态都设置为原图像
    self.heroNavi.tabBarItem.selectedImage = [[UIImage imageNamed:@"yingxiongziliao35*35"] imageWithRenderingMode: UIImageRenderingModeAlwaysOriginal];
    self.heroNavi.tabBarItem.image = [[UIImage imageNamed:@"yingxiongziliao30*30"] imageWithRenderingMode: UIImageRenderingModeAlwaysOriginal];
    
    
    //我
    MineController *mineVC = [[MineController alloc] init];
    mineVC.title = @"我的";
    self.mineNavi = [[UINavigationController alloc] initWithRootViewController:mineVC];
//    self.mineNavi.tabBarItem.image = [UIImage imageNamed:@"mine30*30"];
    //点击和不点击的状态都设置为原图像
    self.mineNavi.tabBarItem.selectedImage = [[UIImage imageNamed:@"mine35*35"] imageWithRenderingMode: UIImageRenderingModeAlwaysOriginal];
    self.mineNavi.tabBarItem.image = [[UIImage imageNamed:@"mine30*30"] imageWithRenderingMode: UIImageRenderingModeAlwaysOriginal];
    
    

    
    NSArray *controllers = @[self.infoNavi, self.heroNavi, self.mineNavi];
    self.viewControllers = controllers; //指定多个试图控制器

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
