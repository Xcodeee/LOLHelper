//
//  RootTabBarController.h
//  UltronNews
//
//  Created by lanouhn on 15/6/16.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootTabBarController : UITabBarController

@property (nonatomic, retain) UINavigationController *infoNavi;
@property (nonatomic, retain) UINavigationController *heroNavi;
@property (nonatomic, retain) UINavigationController *mineNavi;


@end
