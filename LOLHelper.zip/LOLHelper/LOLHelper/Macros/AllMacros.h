



//屏幕的宽度
#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height


//轮播图
#define kScroll @"http://qt.qq.com/static/pages/news/phone/c13_list_1.shtml"

//最新
#define kNews @"http://qt.qq.com/static/pages/news/phone/%@"

//赛事
#define kMatch @"http://qt.qq.com/static/pages/news/phone/%@"

//cell中的视频/视频
#define kMove @"http://qt.qq.com/static/pages/news/phone/%@"

//娱乐
#define kLaugh  @"http://qt.qq.com/static/pages/news/phone/%@"

//官方
#define kOfficial @"http://qt.qq.com/static/pages/news/phone/%@"

//美女
#define kBeauty @"http://qt.qq.com/static/pages/news/phone/%@"

//攻略
#define kStrategy @"http://qt.qq.com/static/pages/news/phone/%@"

//活动
#define kActivity @"http://qt.qq.com/static/pages/news/phone/%@"

//互动话题
#define kTopic @"http://qt.qq.com/php_cgi/lol_mobile/topic/varcache_get_top.php?type=ios"

//赛事详情
#define kSais  @"http://qt.qq.com/static/pages/news/phone/96/article_9096.shtml?APP_BROWSER_VERSION_CODE=1&ios_version=523&imgmode=auto"

//所有的英雄
#define kAllHero @"http://ossweb-img.qq.com/upload/qqtalk/lol_hero/hero_list.js"


