//
//  InfoDetailViewController.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/9.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfoData.h"

@interface InfoDetailViewController : UIViewController
@property (nonatomic, copy) NSString *articleurl;
@property (nonatomic, copy) NSString *isdirect;

@end
