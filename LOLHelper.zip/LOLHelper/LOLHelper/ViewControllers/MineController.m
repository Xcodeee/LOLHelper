//
//  MineController.m
//  UltronNews
//
//  Created by lanouhn on 15/6/16.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "MineController.h"
#import "AllMacros.h"
#import "MineView.h"
#import "MineCell.h"

#import "AboutController.h"

#define kLeft_swichButton               (kScreenWidth - 20 - kWidth_swichButton)
#define kTop_swichButton                15
#define kWidth_swichButton              60
#define kHeight_swichButton             30

#define kLeft_cachLabel                 (kScreenWidth - kWidth_cachLabel)
#define kTop_cachLabel                  15
#define kWidth_cachLabel                100
#define kHeight_cachLabel               30

#define kLeft_button                    (kScreenWidth - 80)
#define kTop_button                     20
#define kWidth_button                   30
#define kHeight_button                  30




@interface MineController ()  <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, retain) MineView *mineSubview;
@property ( nonatomic , strong ) UILabel * cachLabel; //显示缓存大小
@end

@implementation MineController
#pragma mark - lazy load
- (UILabel *)cachLabel {
    if (!_cachLabel) {
        self.cachLabel = [[UILabel alloc] initWithFrame:CGRectMake(kLeft_cachLabel, kTop_cachLabel, kWidth_cachLabel, kHeight_cachLabel)];
        self.cachLabel.textColor = [UIColor grayColor];
    }
    return _cachLabel;
}

- (void)loadView {
    self.mineSubview = [[MineView alloc] initWithFrame:[UIScreen mainScreen] .bounds];
    self.view = _mineSubview;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _mineSubview.mineTable.delegate = self;
    _mineSubview.mineTable.dataSource = self;
    self.view.backgroundColor = [UIColor whiteColor];
    _mineSubview.minePhotoView.image = [UIImage imageNamed:@"AllHero.png"];
    //    _mineSubview.mineTable.scrollEnabled = NO;
    [_mineSubview.mineTable registerClass:[MineCell class] forCellReuseIdentifier:@"dyr"];
    self.navigationItem.title = @"我的";
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MineCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dyr" forIndexPath:indexPath];

    if (indexPath.row == 0) {
        cell.aLabel.text = @"清除缓存";
        cell.picture.image = [UIImage imageNamed:@"Morgana.png"];
        [cell.contentView addSubview:self.cachLabel];
        self.cachLabel.text = [ NSString stringWithFormat: @"%.2f M", [self filePath]];
    } else if (indexPath.row == 1){
        cell.aLabel.text = @"意见反馈";
        cell.picture.image = [UIImage imageNamed:@"Thresh.png"];
        cell.suggestLabel.text = @"官方QQ:365625732";
    } else if (indexPath.row == 2){
        cell.aLabel.text = @"关于";
        cell.picture.image = [UIImage imageNamed:@"Lux.png"];
    }
    return cell;

    
}


//- (void)handleSwitch:(UISwitch *)sender {
//    switch ((NSInteger)sender.on) {
//        case 1:
//            [DKNightVersionManager nightFalling];
//            break;
//        case 0:
//            [DKNightVersionManager dawnComing];
//            break;
//            
//        default:
//            break;
//    }
//}


#pragma mark---UITableViewDelegate
//当tableView的某一行被选中时触发
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        //调用清理缓存方法
        [self clearFile];
    } else if (indexPath.row == 2) {
        AboutController *aboutVC = [[AboutController alloc] init];
        [self.navigationController pushViewController:aboutVC animated:NO];
    }    
}


//获取路径
- (long long) fileSizeAtPath:( NSString *) filePath{
    NSFileManager * manager = [ NSFileManager defaultManager ];
    if ([manager fileExistsAtPath :filePath]){
        return [[manager attributesOfItemAtPath :filePath error : nil ] fileSize ];
    }
    return 0 ;
}

//2: 遍历文件夹获得文件夹大小，返回多少 M（提示：可以在工程界设置（M）
- (float)folderSizeAtPath:( NSString *) folderPath{
    NSFileManager * manager = [ NSFileManager defaultManager ];
    if (![manager fileExistsAtPath :folderPath]) return 0 ;
    NSEnumerator *childFilesEnumerator = [[manager subpathsAtPath :folderPath] objectEnumerator ];
    NSString * fileName;
    long long folderSize = 0 ;
    while ((fileName = [childFilesEnumerator nextObject]) != nil){
        NSString * fileAbsolutePath = [folderPath stringByAppendingPathComponent :fileName];
        folderSize += [ self fileSizeAtPath :fileAbsolutePath];
    }
    return folderSize/( 1024.0 * 1024.0 );
}

// 显示缓存大小----多少M
- (float)filePath
{
    NSString * cachPath = [ NSSearchPathForDirectoriesInDomains ( NSCachesDirectory , NSUserDomainMask , YES ) firstObject ];
    return [ self folderSizeAtPath :cachPath];
}
// 清理缓存
- (void)clearFile
{
    NSString * cachPath = [ NSSearchPathForDirectoriesInDomains ( NSCachesDirectory , NSUserDomainMask , YES ) firstObject ];
    NSArray * files = [[ NSFileManager defaultManager ] subpathsAtPath :cachPath];
    for ( NSString * p in files) {
        NSError * error = nil ;
        NSString * path = [cachPath stringByAppendingPathComponent :p];
        if ([[ NSFileManager defaultManager ] fileExistsAtPath :path]) {
            [[ NSFileManager defaultManager ] removeItemAtPath :path error :&error];
        }
    }
    [ self performSelectorOnMainThread : @selector (clearCachSuccess) withObject : nil waitUntilDone : YES ];
}

//alert提示对话框--清理成功
- ( void )clearCachSuccess
{
    UIAlertView * alertView = [[ UIAlertView alloc ] initWithTitle : @" 提示 " message : @" 缓存清理完毕 " delegate : nil cancelButtonTitle : @" 确定 " otherButtonTitles : nil ];
    [alertView show ];
    [self.mineSubview.mineTable reloadData];
}

//每次进入设置页面都能看到当前的缓存大小
- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:NO animated:YES]; // 不隐藏导航栏
    [self.mineSubview.mineTable reloadData];
}


//- (void)handleDelete:(UIButton *)sender
//{
//    [ShareSDK cancelAuthWithType:ShareTypeSinaWeibo];
//    [ShareSDK cancelAuthWithType:ShareTypeTencentWeibo];
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"注销用户名"  message:nil delegate:self  cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//    [alert show];
//    
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
