//
//  HeroController.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeroController : UIViewController
@property (nonatomic, copy) NSString *urlStr;
@end
