//
//  InformationController.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InformationController.h"
#import "InfoDetailViewController.h"
#import "MJRefresh.h"       //刷新
#import "AFNetWorkRequest.h"  //网路请求helper
#import "SDCycleScrollView.h"   //第三方轮播图
#import "RollingCell.h"     //轮播图
#import "InfoCell.h"
#import "InfomaionView.h"
#import "InfoData.h"
#import "AllMacros.h"



#define kChannelBtnTop              0
#define kChannelBtnWidth            kScreenWidth / 5
#define kChannelBtnHeight           25

#define kChannelScrollTop              20
#define kChannelScrollWidth            kScreenWidth
#define kChannelScrollHeight           25

#define kContentScrollTop            kChannelScrollTop + kChannelScrollHeight
#define kContentScrollWidth          kScreenWidth
#define kContentScrollHeight         kScreenHeight - 50-45

//定义每套Cell的重用标识符
#define kRollingStyleCellReuseIdentifer         @"rollingStyle"


@interface InformationController ()<UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate ,SDCycleScrollViewDelegate>
{
    NSUInteger _btnIndex;
}
@property (nonatomic, retain) InfomaionView *infoView;  //根视图属性
@property (nonatomic, strong) NSMutableDictionary *dataDic;   //存储所有的数据对象
@property (nonatomic, strong) NSMutableArray *titleArr;     //存储轮播图的title
@property (nonatomic, strong) NSMutableArray *imgurlArr;    //存储轮播的图片
@property (nonatomic, strong) NSMutableArray *articleurlArr;  //每个详情网址的参数
@property (nonatomic, strong) NSMutableArray *imagewithbtnArr;     //判断是否有播放按钮
@property (nonatomic, strong) NSMutableArray *isdirectArr;            //判断是否是论坛
@property (nonatomic, strong) NSMutableArray *videoinfoArr;       //视频cell的信息
@property (nonatomic, weak) UITableView *tbView;        //用于识别频道的刷新
@property (nonatomic, strong) NSMutableArray *nextParamArr;
@end

@implementation InformationController

//存放请求数据
- (NSMutableDictionary *)dataDic {
    if (!_dataDic) {
        self.dataDic = [NSMutableDictionary dictionaryWithCapacity:0];
        for (int i = 0; i < 9; i++) {
            NSMutableArray *dataArr = [NSMutableArray arrayWithCapacity:0];
            [self.dataDic setValue:dataArr forKey:[NSString stringWithFormat:@"%d", (300 + i)]];
        }
    }
    return _dataDic;
}


#pragma mark --懒加载--
- (NSMutableArray *)titleArr {
    if (!_titleArr) {
        self.titleArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _titleArr;
}
- (NSMutableArray *)imgurlArr {
    if (!_imgurlArr) {
        self.imgurlArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _imgurlArr;
}
//每个详情网址的参数
- (NSMutableArray *)articleurlArr {
    if (!_articleurlArr) {
        self.articleurlArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _articleurlArr;
}
- (NSMutableArray *)videoinfoArr {
    if (!_videoinfoArr) {
        self.videoinfoArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _videoinfoArr;
}
- (NSMutableArray *)imagewithbtnArr {
    if (!_imagewithbtnArr) {
        self.imagewithbtnArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _imagewithbtnArr;
}
- (NSMutableArray *)ptArr {
    if (!_imagewithbtnArr) {
        self.imagewithbtnArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _imagewithbtnArr;
}
- (NSMutableArray *)isdirectArr {
    if (!_isdirectArr) {
        self.isdirectArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _isdirectArr;
}


//指定根视图
-(void)loadView {
    self.infoView = [[InfomaionView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.view = _infoView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //指定contentScroll的代理
    self.infoView.contentScroll.delegate = self;

    self.nextParamArr = [@[@"c12_list_1.shtml",@"c73_list_1.shtml",@"c11_list_1.shtml",@"c18_list_1.shtml",@"c3_list_1.shtml",@"c17_list_1.shtml",@"c10_list_1.shtml",@"c23_list_1.shtml"]mutableCopy];

    self.automaticallyAdjustsScrollViewInsets = NO;
    [self requestDefaultData];     //请求首页默认数据
    [self configureChannelScroll];  //频道栏
    [self configurePhotoScroll];    //轮播图
    [self upRefresh];       //下拉刷新
    [self loadNewData];     //上来加载
}



//首页请求默认数据
- (void)requestDefaultData {
    //AFNetWorking
    [AFNetWorkRequest getDataWithUrlStr:[NSString stringWithFormat:@"http://qt.qq.com/static/pages/news/phone/c12_list_1.shtml"]  result:^(NSData *data) {
        //避免重复,清空数据
//        [self.dataDic removeAllObjects];
        //解析接口最外层
        NSArray *arr = [data valueForKey:@"list"];
        NSMutableArray *dataArr = self.dataDic[@"300"];

        for (NSDictionary *dic in arr) {
            InfoData *model = [[InfoData alloc] initWithDictionary:dic];
            [dataArr addObject:model];
        }
        [(UITableView *)[self.view viewWithTag:300] reloadData];
    }];
}


#pragma mark - 下拉刷新
- (void)upRefresh{
    // 添加传统的下拉刷新
    _tbView = (UITableView *)[self.view viewWithTag:300 + _btnIndex];
    // 设置刷新颜色
//    tbView.header.textColor = [UIColor redColor];
    [self.tbView addLegendHeaderWithRefreshingBlock:^{

        // 进入刷新状态后会自动调用这个block
        //1.请求数据
        [self AFNetWorkingRequest];
        //2.停止刷新
        NSLog(@"----------------%ld", _tbView.tag);
        [self.tbView.header endRefreshing];
    }];
}
#pragma mark 上拉加载
- (void)loadNewData{
    
    _tbView = (UITableView *)[self.view viewWithTag:300 + _btnIndex];
    // 设置刷新颜色
//    tbView.header.textColor = [UIColor redColor];
    
    // 添加传统的上拉刷新
    // 设置回调（一旦进入刷新状态就会调用这个refreshingBlock）
    [_tbView addLegendFooterWithRefreshingBlock:^{
        //网址中的参数,每次获取数据条数_curIndex
        //1.请求数据
        [self AFNetWorkingRequest];
        //2.停止加载
        [_tbView.footer endRefreshing];
    }];
}


//布局频道栏scrollView
- (void)configureChannelScroll{
     _infoView.channelBtnTitleArr = @[@"最新", @"赛事", @"视频", @"娱乐", @"官方", @"美女", @"攻略"];
    //往频道上添加频道按钮
    for (int i = 0; i < _infoView.channelBtnTitleArr.count; i++) {
        UIButton *channelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        channelBtn.frame = CGRectMake(kChannelBtnWidth * i, 0, kChannelBtnWidth, kChannelBtnHeight);
        [channelBtn setTitle:_infoView.channelBtnTitleArr[i] forState:UIControlStateNormal];
        //设置按钮字体大小
        channelBtn.titleLabel.font = [UIFont systemFontOfSize:20];
        //设置按钮颜色
        if (i == 0) {
            [channelBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        } else {
            [channelBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
        
        //设置按钮tag值
        channelBtn.tag = 100 + i;
        [channelBtn addTarget:self action:@selector(handleChannelBtn:) forControlEvents:UIControlEventTouchUpInside];
        //将频道按钮添加到channelBtnArr数组中
        [_infoView.channelBtnArr addObject:channelBtn];
        //频道按钮添加到scrollView里
        [_infoView.channelScroll addSubview:_infoView.channelBtnArr[i]];
        //让scrollView滚动
//        self.automaticallyAdjustsScrollViewInsets = YES;
        
        UITableView *contentTableView = [[UITableView alloc] initWithFrame:CGRectMake(kScreenWidth * i, 0, kContentScrollWidth, kContentScrollHeight)];
        contentTableView.tag = 300 + i;
        [self.infoView.contentScroll addSubview:contentTableView];
        self.infoView.contentScroll.tag = 200 + i;
        
        //注册两套cell的重用标识符
        [contentTableView registerClass:[RollingCell class] forCellReuseIdentifier:kRollingStyleCellReuseIdentifer];
        [contentTableView registerClass:[InfoCell class] forCellReuseIdentifier:[NSString stringWithFormat:@"infoCell%ld", contentTableView.tag]];
        //指定tableView的代理
        contentTableView.delegate = self;
        contentTableView.dataSource = self;
        
    }
}


#pragma mark - UIScrollViewDelegate
//触发时机:scrollView结束减速时触发.(该方法不一定触发)
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    //获得当前contentTableView的页数
    NSInteger ofSet = _infoView.contentScroll.contentOffset.x  / kScreenWidth;
    for (int i = 0; i < _infoView.channelBtnArr.count; i++) {
        if (ofSet == i) {
            [_infoView.channelBtnArr[i] setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            //判断如果超出范围,滑动频道栏
            if (ofSet >= 2 && ofSet< 6) {

                [_infoView.channelScroll setContentOffset:CGPointMake([UIScreen mainScreen].bounds.size.width / 5 * (ofSet-2), 0)];
            }
        } else {
            [_infoView.channelBtnArr[i] setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
        _btnIndex = ofSet;
    }
    //数据解析
    [self AFNetWorkingRequest];
    //刷新数据
    [self upRefresh];       //下拉刷新
    [self loadNewData];     //上来加载
}


//轮播图
- (void)configurePhotoScroll {
    [AFNetWorkRequest getDataWithUrlStr:kScroll result:^(NSData *data) {
        NSArray *arr = [data valueForKey:@"list"];
        for (NSDictionary *dic in arr) {
            [self.titleArr addObject:dic[@"title"]];
            [self.imgurlArr addObject:dic[@"image_url_big"]];
            [self.articleurlArr addObject:dic[@"article_url"]];
            [self.imagewithbtnArr addObject:dic[@"image_with_btn"]];
            [self.isdirectArr addObject:dic[@"is_direct"]];
            if ([dic objectForKey:@"video_info"] != nil) {
                [self.videoinfoArr addObject:dic[@"video_info"]];
            }
        }
       [(UITableView *)[self.infoView viewWithTag:300] reloadData];
    }];
}



#pragma mark -- SDCycleScrollViewDelegate
//轮播图的点击事件
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index {

    InfoDetailViewController *detailVC = [[InfoDetailViewController alloc] init];
    //进入单图界面之前,将详情的docid传给下个界面
    detailVC.articleurl = self.articleurlArr[index];
    detailVC.isdirect = self.isdirectArr[index];
    [self.navigationController pushViewController:detailVC animated:YES];
}



#pragma mark - Table view data source
//分区数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

//行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSMutableArray *dataArr = self.dataDic[[NSString stringWithFormat:@"%ld", tableView.tag]];
    return dataArr.count;
}

//每行cell的设置
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *key = [NSString stringWithFormat:@"%ld", tableView.tag];
    NSArray *dataArr = self.dataDic[key];
    InfoData *infoData = dataArr[indexPath.row];
    if (_btnIndex == 0 && indexPath.row == 0) {
//        if (indexPath.row == 0) {
            //是首页且是第一行,设置轮播图
            // 监听图片点击，设置代理，实现代理方法
            RollingCell *cell = [tableView dequeueReusableCellWithIdentifier:kRollingStyleCellReuseIdentifer];
            [cell configureFirstCellWithTitleArr:self.titleArr imgrcsArr:self.imgurlArr];
            cell.cycle.delegate = self;
            return cell;
        } else {
            InfoCell *cell = [tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"infoCell%ld", tableView.tag ] forIndexPath:indexPath];
            //给Cell赋值
            [cell configureCellWithInfo:infoData];
            return cell;
        }
//    }
}

#pragma mark - UITableViewDelegate
//选中Cell就push到下一个界面的Controller
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //当前点击的cell中的数据放入model
    NSString *key = [NSString stringWithFormat:@"%ld", tableView.tag];
    NSArray *dataArr = self.dataDic[key];
    InfoData *infoData = dataArr[indexPath.row];
    
    //如果不是视频cell
//    if ([infoData.image_with_btn isEqualToString:@"False"]) {
        InfoDetailViewController *detailVC = [[InfoDetailViewController alloc] init];
        //进入单图界面之前,将详情的docid传给下个界面
        detailVC.articleurl = infoData.article_url;
        detailVC.isdirect = infoData.is_direct;
        [self.navigationController pushViewController:detailVC animated:YES];

}

//动态设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    InfoData *info = self.dataSource[indexPath.row];
    //首行高度设为200
    if (_btnIndex == 0 && indexPath.row == 0) {
        return 200;
    }
    else {    //第二套高度为110
        return 90;
    }

}


#pragma mark - handleAction
//处理点击频道按钮事件
- (void)handleChannelBtn:(UIButton *)sender {

    //根据按钮下标移动contentscroll
    _btnIndex = sender.tag - 100;
    [_infoView.contentScroll setContentOffset:CGPointMake(kScreenWidth * _btnIndex, 0) animated:YES];
    [_infoView.channelBtnArr[_btnIndex] setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    
    //判断点击按钮是否是当前页面的按钮,是,不变色,不是,变红
    NSInteger contentOfSet = _infoView.contentScroll.contentOffset.x  / kScreenWidth;
    if (contentOfSet != _btnIndex) {
        [_infoView.channelBtnArr[contentOfSet] setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
        //数据解析
        [self AFNetWorkingRequest];
}



//AFNetWorking数据请求
- (void)AFNetWorkingRequest {
//    AFNetWorking
    [AFNetWorkRequest getDataWithUrlStr:[NSString stringWithFormat:_infoView.channelAPIArr[_btnIndex], _nextParamArr[_btnIndex]] result:^(NSData *data) {
        NSMutableArray *dataArr = self.dataDic[[NSString stringWithFormat:@"%ld", _btnIndex + 300]];
        NSArray *arr = [data valueForKey:@"list"];
        //再次获取下个界面的参数
            [_nextParamArr replaceObjectAtIndex:_btnIndex withObject:[data valueForKey:@"next"]];

        
        for (NSDictionary *dic in arr) {
            InfoData *model = [[InfoData alloc] initWithDictionary:dic];
            [dataArr addObject:model];            
        }
        [(UITableView *)[self.infoView viewWithTag:_btnIndex + 300] reloadData];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:YES animated:YES]; // 隐藏导航栏
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
