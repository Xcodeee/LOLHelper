
//
//  HeroController.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "HeroController.h"
#import "HeroView.h"
#import "HeroCell.h"
#import "HeroData.h"
#import "AllMacros.h"
#import "HeroDetailController.h"
#import "NetWorkEngine.h"


#define kItemWidth                  (kScreenWidth - 30) / 2
#define kItemHeight                 kItemWidth * 2 / 5

@interface HeroController ()<UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, dataParserDelegate>
@property (nonatomic, retain) HeroView *heroView;  //根视图属性
@property (nonatomic, strong) NSMutableArray *datasourc;

@end

@implementation HeroController

//存放请求数据
- (NSMutableArray *)datasourc {
    if (!_datasourc) {
        self.datasourc = [NSMutableArray arrayWithCapacity:0];
    }
    return _datasourc;
}
//指定根视图
-(void)loadView {
    self.heroView = [[HeroView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.view = _heroView;
   
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    

    
    self.title = @"英雄资料";
    //配置数据源对象
    _heroView.collectView.dataSource = self;
    //配置代理对象
    _heroView.collectView.delegate = self;
    
    [self.view addSubview:_heroView.collectView];
    //注册cell
    [_heroView.collectView registerClass:[HeroCell class] forCellWithReuseIdentifier:@"item"];
    
    //创建这个类型,请求数据
    NetWorkEngine *engine = [[NetWorkEngine alloc] init];
    engine.delegate = self;
    [engine loadDataWithString:kAllHero];
}

#pragma mark -------- 解析的真谛!!
//请求默认数据
//- (void)requestDefaultData {
//    NSURL *url = [NSURL URLWithString:kAllHero];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
//    //解析接口最外层
//    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
//    NSArray *array = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
////    NSLog(@"--------------%@", array);
//    for (NSDictionary *dic in NSArray *array) {
//        //model赋值并放到数组
//        HeroData *heroDta = [[HeroData alloc] init];
//        [heroDta setValuesForKeysWithDictionary:dic];
//        NSLog(@"====================%@", dic);
//        //将model添加到数组中
//        [self.datasourc addObject:heroDta];
//    }
//
//    [self.heroView.collectView reloadData];
//}
#pragma mark -------- end

- (void)parserDataWithData:(NSMutableData *)data {
    
    NSMutableArray *array = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];

    for (NSDictionary *dic in array) {
        //model赋值并放到数组
        HeroData *heroDta = [[HeroData alloc] init];
        [heroDta setValuesForKeysWithDictionary:dic];
        NSLog(@"====================%@", dic);
        //将model添加到数组中
        [self.datasourc addObject:heroDta];
    }
    
    [self.heroView.collectView reloadData];
}


#pragma mark - UICollectionViewDataSource
//设置collectionView分区个数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}
//设置每个分区item的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    NSLog(@"self.datasourc.count = %ld", self.datasourc.count);
    return self.datasourc.count;
}
//针对于每个item返回对应的cell对象,cell
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    HeroCell *herocell = [collectionView dequeueReusableCellWithReuseIdentifier:@"item" forIndexPath:indexPath];
    
    //取到model
    HeroData *herodata = self.datasourc[indexPath.row];
    //给cell赋值
    [herocell configureCellWithModel:herodata];

    return herocell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UICollectionViewDelegate
//item点击事件
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    HeroDetailController *heroDVC = [[HeroDetailController alloc] init];
    NSArray *dataArr = self.datasourc;
    HeroData *heroData = dataArr[indexPath.row];
    //①传需要的值:进入单图界面之前,将详情的key值传给下个界面
//    heroDVC.heroID = heroData.id;
    //②传整个model
    heroDVC.heroDta = heroData;
    [self.navigationController pushViewController:heroDVC animated:YES];
}

#pragma mark - UICollectionViewDelegateFlowLayout
//动态设置每个item的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(kItemWidth, kItemHeight);
}
//动态设置每个分区最小item间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}
//动态设置每个分区的最小行间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 20;
}
//动态设置每个分区的缩进量
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:NO animated:YES]; // 不隐藏导航栏
}
@end