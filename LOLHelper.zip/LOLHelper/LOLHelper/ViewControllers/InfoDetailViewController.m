 //
//  InfoDetailViewController.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/9.
//  Copyright (c) 2015年 HJL. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "InfoDetailViewController.h"
#import "InformationController.h"
#import "InfomaionView.h"
#import "AFNetWorkRequest.h"

@interface InfoDetailViewController ()<UIWebViewDelegate>
{
    UIWebView *WEBView;
    NSURL *url;
}
@end

@implementation InfoDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    WEBView.delegate = self;
    WEBView = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    WEBView.scalesPageToFit = YES;
    [self.view addSubview:WEBView];

    
    if ([_articleurl rangeOfString:@"http"].location != NSNotFound) {
        if ([_articleurl rangeOfString:@".htm"].location != NSNotFound) {
            url = [NSURL URLWithString:[NSString stringWithFormat:@"%@", _articleurl]];
        } else {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"%@&APP_BROWSER_VERSION_CODE=1&ios_version=523&imgmode=auto", _articleurl]];
        }
    } else {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://qt.qq.com/static/pages/news/phone/%@?APP_BROWSER_VERSION_CODE=1&ios_version=523&imgmode=auto", _articleurl]];
        NSLog(@"--------------%@", url);
    }
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [WEBView loadRequest:request];

    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSString *htmlString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];

//     修改字符串
    if ([_isdirect isEqualToString:@"False"]) {
        NSRange range1 = [htmlString rangeOfString:@"未安装"];
        NSRange range2 = [htmlString rangeOfString:@"location.href=QTLshare.DownLoadAPP"];
        // 创建中间变量字符串
        NSMutableString *tempStr = [NSMutableString stringWithString:htmlString];
        // 开始裁剪
        [tempStr replaceCharactersInRange:NSMakeRange(range1.location - 3, range2.location - range1.location + 5) withString:@""];
        // 接收裁剪后的字符串
        NSString *newStr = [NSString stringWithString:tempStr];
        
        [WEBView loadHTMLString:newStr baseURL:nil];
    }
   
}


- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [webView stringByEvaluatingJavaScriptFromString:
     @"var script = document.createElement('script');"
     "script.type = 'text/javascript';"
     "script.text = \"function ResizeImages() { "
     "var myimg,oldwidth;"
     "var maxwidth = 310;" // UIWebView中显示的图片宽度
     "for(i=0;i <document.images.length;i++){"
     "myimg = document.images[i];"
     "if(myimg.width > maxwidth){"
     "oldwidth = myimg.width;"
     "myimg.width = maxwidth;"
     "}"
     "}"
     "}\";"
     "document.getElementsByTagName('head')[0].appendChild(script);"];
    [webView stringByEvaluatingJavaScriptFromString:@"ResizeImages();"];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    WEBView.delegate = self;
[self.navigationController setNavigationBarHidden:NO animated:YES]; // 隐藏导航栏
    self.view.backgroundColor = [UIColor whiteColor];
}


@end
