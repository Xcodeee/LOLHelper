//
//  InformationController.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InformationController : UIViewController
@property (nonatomic, copy) NSString *tempParm; //存放网址拼接参数
@end
