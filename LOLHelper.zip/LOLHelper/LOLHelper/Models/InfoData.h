//
//  NewsData.h
//  UltronNews
//
//  Created by lanouhn on 15/6/5.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InfoData : NSObject

@property (nonatomic, copy) NSString *title; //标题
@property (nonatomic, copy) NSString *summary;   //简介
@property (nonatomic, copy) NSString *publication_date;    //发布时间
@property (nonatomic, copy) NSString *image_url_big;    //图片链接
@property (nonatomic, copy) NSString *article_url;      //详情页网址参数
@property (nonatomic, copy) NSString *is_direct;           //判断是否是论坛类
@property (nonatomic, copy) NSString *video_info;       //视频参数
@property (nonatomic, copy) NSString *image_with_btn;   //视频
@property (nonatomic, copy) NSString *next;          //加载网址参数

- (id)initWithDictionary:(NSDictionary *)dic;
+ (id)newsDataWithDictionary:(NSDictionary *)dic;   //便利构造器
@end
