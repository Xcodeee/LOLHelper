//
//  NewsData.m
//  UltronNews
//
//  Created by lanouhn on 15/6/5.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "InfoData.h"

@implementation InfoData 
- (id)initWithDictionary:(NSDictionary *)dic {
    self = [super init];
    if (self) {
        //KVC赋值
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

//便利构造器
+ (id)newsDataWithDictionary:(NSDictionary *)dic {
    return [[self alloc] initWithDictionary:dic];
}

//未使用的key调用这个方法
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}



@end
