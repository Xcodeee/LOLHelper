//
//  InfoCell.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/9.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "InfoCell.h"
#import "AllMacros.h"
#import "UIImageView+WebCache.h"
#import "InfoData.h"

#define kMarginLeft_infoPhotoView       10
#define kMarginTop_infoPhotoView        5
#define kWidth_infoPhotoView            100
#define kHeight_infoPhotoView           80

#define kMarginLeft_infoTitle           (kMarginLeft_infoPhotoView + kWidth_infoPhotoView + 10)
#define kMarginTop_infoTitle            5
#define kWidth_infoTitle                (kScreenWidth - kWidth_infoPhotoView - 30)
#define kHeight_infoTitle               25

#define kMarginLeft_infoDigest          kMarginLeft_infoTitle
#define kMarginTop_infoDigest           (kMarginTop_infoPhotoView + kHeight_infoTitle)
#define kWidth_infoDigest               kWidth_infoTitle
#define kHeight_infoDigest              40

#define kMarginLeft_infoPublicTime       (kScreenWidth - kWidth_infoPublicTime - 10)
#define kMarginTop_infoPublicTime        (kMarginTop_infoDigest + kHeight_infoDigest)
#define kWidth_infoPublicTime            100
#define kHeight_infoPublicTime           20

#define kMarginLeft_mv                  kMarginLeft_infoTitle
#define kMarginTop_mv                   kMarginTop_infoPublicTime
#define kWidth_mv                       50
#define kHeight_mv                      kHeight_infoPublicTime

@implementation InfoCell
#pragma mark - lazy load
- (UIImageView *)infoPhotoView {
    if (!_infoPhotoView) {
        self.infoPhotoView = [[UIImageView alloc] initWithFrame:CGRectMake(kMarginLeft_infoPhotoView, kMarginTop_infoPhotoView, kWidth_infoPhotoView, kHeight_infoPhotoView)];
        //设置圆角
        self.infoPhotoView.layer.cornerRadius = self.infoPhotoView.frame.size.height/6;
        self.infoPhotoView.layer.masksToBounds = YES;
        //设置边框
        self.infoPhotoView.layer.borderWidth = 0.5;
        self.infoPhotoView.layer.borderColor = [UIColor blackColor].CGColor;
        
    }
    return _infoPhotoView;
}

- (UILabel *)infoTitle {
    if (!_infoTitle) {
        self.infoTitle = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_infoTitle, kMarginTop_infoTitle, kWidth_infoTitle, kHeight_infoTitle)];
//        _infoTitle.nightTextColor = [UIColor lightGrayColor];
    }
    return _infoTitle;
}

- (UILabel *)infoSummary {
    if (!_infoSummary) {
        self.infoSummary = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_infoDigest, kMarginTop_infoDigest, kWidth_infoDigest, kHeight_infoDigest)];
        //不限制行数
        _infoSummary.numberOfLines = 0;
        _infoSummary.font = [UIFont systemFontOfSize:14];
        _infoSummary.textColor = [UIColor grayColor];
//        _infoSummary.nightTextColor = [UIColor lightGrayColor];
    }
    return _infoSummary;
}

- (UILabel *)infoPublicTime {
    if (!_infoPublicTime) {
        self.infoPublicTime = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_infoPublicTime, kMarginTop_infoPublicTime, kWidth_infoPublicTime, kHeight_infoPublicTime)];
        _infoPublicTime.font = [UIFont systemFontOfSize:10];
        _infoPublicTime.textColor = [UIColor grayColor];
//        _infoPublicTime.nightTextColor = [UIColor lightGrayColor];
    }
    return _infoPublicTime;
}
- (UILabel *)mv {
    if (!_mv) {
        self.mv = [[UILabel alloc] initWithFrame:CGRectMake(kMarginLeft_mv, kMarginTop_mv, kWidth_mv, kHeight_mv)];
        _mv.text = @"视频";
        _mv.font = [UIFont systemFontOfSize:13];
        _mv.textColor = [UIColor redColor];
    }
    return _mv;
}

//赋值方法,存放一条信息
- (void)configureCellWithInfo:(InfoData *)infoData {    
    //图片,给定图片链接
    [self.infoPhotoView sd_setImageWithURL:[NSURL URLWithString:infoData.image_url_big]];
    //标题
    self.infoTitle.text = infoData.title;
    //简介
    self.infoSummary.text = infoData.summary;
    //发布时间
    self.infoPublicTime.text = infoData.publication_date;
#warning bug?????
    //添加"视频"label
    if ([infoData.image_with_btn isEqual:@"True"]) {
        [self addSubview:self.mv];
    }
}

//cell的初始化方法
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
//        [DKNightVersionManager addClassToSet:self.class];
//        self.nightBackgroundColor = UIColorFromRGB(0x343434);
        //添加子控件
        [self.contentView addSubview:self.infoPhotoView];
        [self.contentView addSubview:self.infoTitle];
        [self.contentView addSubview:self.infoSummary];
        [self.contentView addSubview:self.infoPublicTime];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
