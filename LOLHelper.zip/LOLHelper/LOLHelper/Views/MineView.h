//
//  MineView.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MineView : UIView

@property (nonatomic, strong) UIImageView *minePhotoView;   //头像
@property (nonatomic, strong) UITableView *mineTable;

@end
