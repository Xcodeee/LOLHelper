//
//  RollingCell.m
//  UltronNews
//
//  Created by lanouhn on 15/6/11.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "RollingCell.h"
#import "AllMacros.h"
#import "SDCycleScrollView.h"



@implementation RollingCell

////夜间模式
//- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
//    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
//        //
//        [DKNightVersionManager addClassToSet:self.class];
//        self.nightBackgroundColor = UIColorFromRGB(0x343434);
//
//    }
//    return self;
//}

//赋值
- (void)configureFirstCellWithTitleArr:(NSMutableArray *)titleArr imgrcsArr:(NSMutableArray *)imgrcsArr {
    NSMutableArray *URLsGroup = [NSMutableArray arrayWithCapacity:0];
    for (NSString *str in imgrcsArr) {
        NSURL *url = [NSURL URLWithString:str];
        [URLsGroup addObject:url];
    }
    self.cycle = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, kScreenWidth, 200) imageURLsGroup:URLsGroup];
    self.cycle.titlesGroup = titleArr;
    self.cycle.autoScrollTimeInterval = 2.0;
    
    
    [self addSubview:self.cycle];
}



@end
