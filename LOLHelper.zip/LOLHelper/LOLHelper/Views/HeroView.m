//
//  HeroView.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "HeroView.h"

@implementation HeroView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        //添加子控件
        [self addSubview:self.collectView];
    }
    return self;
}
//懒加载
- (UICollectionView *)collectView {
    if (!_collectView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        self.collectView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 44) collectionViewLayout:layout];
        
        _collectView.backgroundColor = [UIColor whiteColor];
    }
    return _collectView;
}

@end
