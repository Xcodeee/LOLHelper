//
//  InfomaionView.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfomaionView : UIView

@property (nonatomic, strong) UIScrollView *channelScroll;  //频道栏
@property (nonatomic, strong) UIScrollView *contentScroll;  //频道栏对应内容
@property (nonatomic, strong) NSMutableArray *channelBtnArr;     //频道按钮数组
@property (nonatomic, strong) NSArray *channelBtnTitleArr;   //频道按钮标题
@property (nonatomic, strong) NSArray *channelAPIArr;   //频道按钮对应的API

//@property (nonatomic, retain) UITableView *contentTableView; //内容cell
@end
