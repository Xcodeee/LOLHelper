//
//  InfomaionView.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "InfomaionView.h"
#import "AllMacros.h"


#define kChannelScrollTop              20
#define kChannelScrollWidth            kScreenWidth / 5
#define kChannelScrollHeight           25

#define kContentScrollTop            kChannelScrollTop + kChannelScrollHeight
#define kContentScrollWidth          kScreenWidth
#define kContentScrollHeight         kScreenHeight - kContentScrollTop

@implementation InfomaionView

#pragma  mark - lazy Load
- (NSMutableArray *)channelBtnArr {
    if (!_channelBtnArr) {
        self.channelBtnArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _channelBtnArr;
}



- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self addAllView];
        self.backgroundColor = [UIColor lightGrayColor];
    }
    return self;
}



//懒加载API数组
- (NSArray *)channelAPIArr {
    if (!_channelAPIArr) {
        self.channelAPIArr = [NSArray arrayWithObjects:kNews,kMatch,kMove,kLaugh,kOfficial,kBeauty,kStrategy, nil];
    }
    return _channelAPIArr;
}


- (void)addAllView {
    CGRect frame = CGRectMake(0, kChannelScrollTop, kScreenWidth, kChannelScrollHeight);
    self.channelScroll = [[UIScrollView alloc] initWithFrame:frame];
    //scrollView的内容页大小
    _channelScroll.contentSize = CGSizeMake(kChannelScrollWidth * self.channelAPIArr.count, 25);
    //关闭横向滚动条显示
    _channelScroll.showsHorizontalScrollIndicator = NO;
    //设置scrollView能否滑动
    _channelScroll.scrollEnabled = NO;
    [self addSubview:_channelScroll];
    
    
    
    //添加与频道对应的contentScroll用于展示
    self.contentScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0,kContentScrollTop, kContentScrollWidth, kContentScrollHeight)];
    self.contentScroll.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:self.contentScroll];
    
    self.contentScroll.contentSize = CGSizeMake(kContentScrollWidth * self.channelAPIArr.count, kContentScrollHeight);
    //整屏滑动contentScroll
    self.contentScroll.pagingEnabled = YES;
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
