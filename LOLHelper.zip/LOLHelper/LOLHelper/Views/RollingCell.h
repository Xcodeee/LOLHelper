//
//  RollingCell.h
//  UltronNews
//
//  Created by lanouhn on 15/6/11.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SDCycleScrollView;
@interface RollingCell : UITableViewCell
@property (nonatomic, retain) SDCycleScrollView *cycle;

- (void)configureFirstCellWithTitleArr:(NSMutableArray *)titleArr imgrcsArr:(NSMutableArray *)imgrcsArr;

@end
