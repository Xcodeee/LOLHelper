//
//  MineView.m
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import "MineView.h"


#define kScreenWidth [UIScreen mainScreen].bounds.size.width   //屏幕宽度
#define kScreenHeight [UIScreen mainScreen].bounds.size.height



#define kMarginLeft_MinePhotoView       0
#define kMarginTop_MinePhotoView        64
#define kWidth_MinePhotoView            kScreenWidth
#define kHeight_MinePhotoView           kScreenHeight/2

#define kMarginLeft_MineTable           0
#define kMarginTop_MineTable            kHeight_MinePhotoView
#define kWidth_MineTable                kScreenWidth
#define kHeight_MineTable               kScreenHeight  -  kHeight_MinePhotoView - 48



@implementation MineView


- (UIImageView *)minePhotoView {
    if (!_minePhotoView) {
        self.minePhotoView = [[UIImageView alloc] initWithFrame:CGRectMake(kMarginLeft_MinePhotoView, kMarginTop_MinePhotoView, kWidth_MinePhotoView, kHeight_MinePhotoView)];
    }
    return _minePhotoView;
}
- (UITableView *)mineTable {
    if (!_mineTable) {
        self.mineTable = [[UITableView alloc] initWithFrame:CGRectMake(kMarginLeft_MineTable, kMarginTop_MineTable, kWidth_MineTable, kHeight_MineTable)];
    }
    return _mineTable;
}




- (void)addAllViews {
    [self addSubview: self.minePhotoView];
    [self addSubview:self.mineTable];
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self addAllViews];
//        self.nightBackgroundColor = UIColorFromRGB(0x343434);
//        [DKNightVersionManager addClassToSet:self.class];
    }
    return self;
}


@end
