//
//  InfoCell.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/9.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfoData.h"    //获取网址
@interface InfoCell : UITableViewCell

@property (nonatomic, strong) UIImageView *infoPhotoView;   //图片
@property (nonatomic, strong) UILabel *infoTitle;   //新闻标题
@property (nonatomic, strong) UILabel *infoSummary;  //新闻概要
@property (nonatomic, strong) UILabel *infoPublicTime; //发布时间
@property (nonatomic, strong) UILabel *mv;          //如果是视频,添加视频label
@property (nonatomic, copy) NSString *imgbtn;
//赋值方法
- (void)configureCellWithInfo:(InfoData *)infoData;

@end
