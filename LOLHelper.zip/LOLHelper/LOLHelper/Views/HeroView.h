//
//  HeroView.h
//  LOLHelper
//
//  Created by lanouhn on 15/7/8.
//  Copyright (c) 2015年 HJL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeroView : UIView
@property (nonatomic, strong) UICollectionView *collectView;
@end
